﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumerationaApp.AutobuskaStanica
{
    public enum Linija
    {
        Gradksi,
        Medjugradski,
        Lokalni
    }

    public class Polazak
    {
        #region Attributes

        private string destinacija;
        private DateTime datum;
        private int brojSlobodnihMesta;
        private Linija gradskaLinija;

        #endregion

        #region Get and Set 

        public string Destinacija
        {
            get { return destinacija; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception("Destinacija ne sme biti prazna.");
                }
                else
                {
                    destinacija = value;
                }
            }
        }


        public DateTime Datum
        {
            get { return datum; }
            set
            {
                if (value == null || value < DateTime.Now)
                {
                    throw new Exception("Datum mora biti posle danasnjeg");
                }
                else
                {
                    datum = value;
                }
            }
        }


        public int BrojSlobodnihMesta
        {
            get { return brojSlobodnihMesta; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("Broj mesta mora biti veci od nula.");
                }
                else
                {
                    brojSlobodnihMesta = value;
                }
            }
        }

        public Linija GradskaLinija
        {
            get { return gradskaLinija; }
            set { gradskaLinija = value;}
        }

        #endregion

        #region ToString

        public override string ToString()
        {
            return $"Destinacija: {destinacija} Linija: {gradskaLinija} Datum: {datum} Broj mesta: {brojSlobodnihMesta}";
        }

        #endregion
    }
}
