﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumerationaApp.AutobuskaStanica
{
    public class AutobuskaStanica
    {
        #region Attributes

        private List<Polazak> polasci;

        #endregion

        #region Constructor

        public AutobuskaStanica()
        {
            polasci = new List<Polazak>();
        }

        #endregion

        #region Methods
        public void UnesiPolazak(Polazak polazak)
        {
            if(polazak != null)
            {
                polasci.Add(polazak);
            }
            else
            {
                throw new Exception("Polazak je prazan.");
            }
        }


        public bool RezervisiKarte(string destinacija, int brojKarata, DateTime dan)
        {
            foreach (var item in polasci)
            {
                if (item.Destinacija.Equals(destinacija)
                    && item.Datum == dan && item.BrojSlobodnihMesta > brojKarata)
                {
                    item.BrojSlobodnihMesta = item.BrojSlobodnihMesta - brojKarata;
                    return true;
                }
            }
            return false;
        }


        #endregion
    }
}
