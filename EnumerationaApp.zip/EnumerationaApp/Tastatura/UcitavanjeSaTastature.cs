﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumerationaApp.Tastatura
{
    public class UcitavanjeSaTastature
    {
        public static void BrojRecenicaSaTackom()
        {
            try
            {
                Console.Write("Unesite tekst: ");
                string tekst = Console.ReadLine();
                int tacka = 0;

                for (int i = 0; i < tekst.Length; i++)
                {
                    if (tekst[i] == '.') { tacka++; }
                }

                Console.WriteLine("Broj recenica: " + tacka);
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void BrojReci()
        {
            try
            {
                Console.Write("Unesite tekst: ");
                string tekst = Console.ReadLine();

                string[] reci = tekst.Split(' ');
                int brojReci = reci.Length;

                Console.WriteLine("Broj reci: " + brojReci );
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void PonavljanjeReciSneg()
        {
            try
            {
                Console.Write("Unesite tekst: ");
                string tekst = Console.ReadLine();
                int brojac = 0;

                string[] nizReci = tekst.Replace('.', ' ').Replace(',', ' ').ToLower().Split(' ');

                for (int i = 0; i < nizReci.Length; i++)
                {
                    if (nizReci[i].Equals("sneg"))
                    {
                        brojac++;
                    }
                }
                
                Console.WriteLine("Broj pojavljivanja reci sneg: " +brojac);
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void MetriUKilometre()
        {
            try
            {
                Console.Write("Unesite tekst: ");
                string tekst = Console.ReadLine();

                double metri = double.Parse(tekst);
                double kilometri = metri / 1000;

                Console.WriteLine("Kilometri: " + kilometri);
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void SumaRealnih()
        {
            try
            {
                Console.Write("Unesite tekst: ");
                string tekst = string.Empty;
                double zbir = 0;

                while (!tekst.Equals("kraj"))
                {
                    tekst = Console.ReadLine();
                    double broj = double.Parse(tekst);
                    zbir = zbir + broj;
                }

                Console.WriteLine("Zbir: " + zbir);
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

    }
}
