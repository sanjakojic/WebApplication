﻿using EnumerationaApp.AutobuskaStanica;
using EnumerationaApp.Tastatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumerationaApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //int x = (int)DaniUNedelji.Petak;

            //string nazivDana = DaniUNedeljiEnum.VratiNazivDana(DaniUNedelji.Nedelja);

            //Console.WriteLine(nazivDana);

            //Polazak polazak = new Polazak();
            //polazak.Destinacija = "Novi Sad";
            //polazak.BrojSlobodnihMesta = 55;
            //polazak.Datum = new DateTime(2018, 12, 20);
            //polazak.GradskaLinija = Linija.Medjugradski;

            //Polazak polazak2 = null;

            //AutobuskaStanica.AutobuskaStanica stanica = new AutobuskaStanica.AutobuskaStanica();
            //try
            //{
            //    stanica.UnesiPolazak(polazak);
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e.Message);
            //}

            //bool result = stanica.RezervisiKarte("Novi Sad", 26, new DateTime(2018, 12, 20));
            //if (result)
            //{
            //    Console.WriteLine("Rezervisano!");
            //}
            //else
            //{
            //    Console.WriteLine("Nije uspesna rezervacija.");
            //}

            //    try
            //    {
            //        Console.Write("Unesite realan broj: ");
            //        string poruka = Console.ReadLine();

            //        double broj = double.Parse(poruka);
            //        Console.WriteLine("Kvadrat je: " + (broj + broj));
            //        int brojac = 0;

            //        while (brojac < 10)
            //        {
            //            Console.Write("Unesite ceo broj: ");
            //            string poruku = Console.ReadLine();

            //            int broj = int.Parse(poruku);
            //            if (broj % 2 == 0)
            //            {
            //                Console.WriteLine("Broj je paran.");
            //            }
            //            else
            //            {
            //                Console.WriteLine("Broj nije paran.");
            //            }
            //            brojac++;
            //        }

            //        Console.ReadLine(); 
            //    }
            //    catch (Exception e)
            //    {
            //        Console.WriteLine(e);
            //        Console.ReadLine();
            //    }


            //UcitavanjeSaTastature.BrojRecenicaSaTackom();
            //UcitavanjeSaTastature.BrojReci();
            //UcitavanjeSaTastature.PonavljanjeReciSneg();
            //UcitavanjeSaTastature.MetriUKilometre();
            UcitavanjeSaTastature.SumaRealnih();

        }
    }
}
