﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumerationaApp
{
    public enum DaniUNedelji
    {
        Ponedeljak = 10,
        Utorak,
        Sreda,
        Cetvrtak,
        Petak,
        Subota,
        Nedelja
    }

    public class DaniUNedeljiEnum
    {

        public static string VratiNazivDana(DaniUNedelji dan)
        {
            switch (dan)
            {
                case DaniUNedelji.Ponedeljak: return "Ponedeljak";
                case DaniUNedelji.Utorak: return "Utorak";
                case DaniUNedelji.Sreda: return "Sreda";
                case DaniUNedelji.Cetvrtak: return "Cetvrtak";
                case DaniUNedelji.Petak: return "Petak";
                case DaniUNedelji.Subota: return "Subota";
                case DaniUNedelji.Nedelja: return "Nedelja";
            }
            return string.Empty;
        }
        
    }
}
