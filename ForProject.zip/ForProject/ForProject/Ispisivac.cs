﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForProject
{
    public class Ispisivac
    {
        public static void IspisiPorukuPetPuta()
        {
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine("Dobar dan! :)");
            }

            // i = i + 1;
            //i++
            // i = i - 1;
            //i--;
        }

        public static void IspisiPorukuNPuta(string poruka, int n)
        {
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(poruka);
            }
        }

        public static void IspisiOd0Do30()
        {
            for (int i = 0; i <= 30; i++)
            {
                Console.WriteLine(i);
            }
        }

        public static void IspisiOd30Do0()
        {
            for (int i = 30; i >= 0; i--)
            {
                Console.Write(i + " ");
            }
        }

        public static void IspisiMatricu()
        {
            for (int i = 1; i <= 6; i++)
            {
                for (int j = 1; j <= 4; j++)
                {
                    Console.Write(" 1 ");
                }
                Console.WriteLine();
            }
        }

        public static void IspisiMinDeljive()
        {
            for (int i = 10; i <= 1000; i++)
            {
                if ((i % 12 == 0) && (i % 15 == 0) && (i % 9 == 0))
                {
                   Console.WriteLine(i);
                   break;
                }
            }
        }

        public static int VratiMinDeljive()
        {
            for (int i = 10; i <= 1000; i=i+50)
            {
                if ((i % 12 == 0) && (i % 15 == 0) && (i % 9 == 0) && (i % 19 == 0) && (i % 33 == 0))
                {
                    return i;
                }
            }
            return 0;
        }
    }
}
