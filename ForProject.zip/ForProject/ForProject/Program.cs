﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForProject
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Ispisivac.IspisiPorukuPetPuta();

            //Ispisivac.IspisiPorukuNPuta("Hello", 3);

            //Ispisivac.IspisiOd0Do30();

            //Ispisivac.IspisiOd30Do0();

            //Ispisivac.IspisiMatricu();

            //Ispisivac.IspisiMinDeljive();

            int rezultat = Ispisivac.VratiMinDeljive();
            Console.WriteLine(rezultat);

            Console.ReadLine();
        }
    }
}
