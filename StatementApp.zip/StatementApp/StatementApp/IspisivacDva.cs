﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace StatementApp
{
    public class IspisivacDva
    {
        public static void IspisiOd1Do50()
        {
            for (int i = 1; i <= 50; i++)
            {
                Console.Write(i);
            }
        }

        public static void IspisiOd0Do30()
        {
            for (int i = 0; i <= 30; i++)
            {
                Console.Write(i);
            }
        }

        public static void IspisiOd50Do1()
        {
            for (int i = 50; i >= 1; i--)
            {
                Console.Write(i);
            }
        }

        public static void IspisiOd32DoMinus2()
        {
            for (int i = 32; i >= -2; i--)
            {
                Console.Write(i);
            }
        }


        public static void IspisiOd0DoN(int n)
        {
            for (int i = 0; i <= n; i++)
            {
                Console.Write(i);
            }
        }

        public static void IspisiOdNDo0(int n)
        {
            for (int i = 0; i >= n; i--)
            {
                Console.Write(i);
            }
        }

        public static void IspisiBrojeveADoB(int a, int b)
        {
            for (int i = a; i <= b; i++)
            {
                Console.Write(i);
            }
        }

        public static void IspisiBrojeveBezAB(int a, int b)
        {
            for (int i = a + 1; i < b; i++)
            {
                Console.Write(i);
            }
        }

        public static void IspisiOdADoBUnazad(int a, int b)
        {
            for (int i = b; i >= a; i--)
            {
                Console.Write(i);
            }
        }
    }
}
