﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //IspisivacDva.IspisiOd1Do50();
            //Console.WriteLine();
            //IspisivacDva.IspisiOd0Do30();
            //Console.WriteLine();
            //IspisivacDva.IspisiOd50Do1();
            //Console.WriteLine();
            //IspisivacDva.IspisiOd32DoMinus2();
            //Console.WriteLine();

            //IspisivacDva.IspisiOd0DoN(12);
            //Console.WriteLine();
            //IspisivacDva.IspisiOdNDo0(-5);
            //Console.WriteLine();
            //IspisivacDva.IspisiBrojeveADoB(10,20);
            //Console.WriteLine();
            //IspisivacDva.IspisiBrojeveBezAB(10,20);
            //Console.WriteLine();
            //IspisivacDva.IspisiOdADoBUnazad(1,11);

            //Uvecanje.VeciOd1000(2);

            //Poruka.Prvih10DeljivihSa9Ili6();

            //Poruka.Prvih5DeljivihSa7I8();

            //Poruka.PrvihNDeljivihSa5Ili6(5);


            Console.ReadLine();
        }

        
    }
}
