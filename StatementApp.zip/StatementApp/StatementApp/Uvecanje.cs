﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementApp
{
    public class Uvecanje
    {
        public static void VeciOd1000(int a)
        {
            int rezultat = 1;

            while (rezultat < 1000)
            {
                rezultat = rezultat * a;
            }
            Console.WriteLine(rezultat);
        }
    }
}
