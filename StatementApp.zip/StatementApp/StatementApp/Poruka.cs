﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementApp
{
    public class Poruka
    {
        public static void Prvih10DeljivihSa9Ili6()
        {
            int brojac = 0;
            int broj = 1;

            while (brojac < 10)
            {
                if ((broj % 6 == 0) || (broj % 9 == 0))
                {
                    Console.WriteLine(broj);
                    brojac++;
                }
                broj++;
            }
        }


        public static void Prvih5DeljivihSa7I8()
        {
            int brojac = 0;
            int broj = 1;
            while (brojac < 5)
            {
                if ((broj % 7 == 0) && (broj % 8 == 0))
                {
                    Console.WriteLine(broj);
                    brojac++;
                }
                broj++;
            }
        }

        public static void PrvihNDeljivihSa5Ili6(int n)
        {
            int i = 0;
            int broj = 1;
            while (i < n)
            {
                if ((broj % 5 == 0) || (broj % 6 == 0))
                {
                    Console.WriteLine(broj);
                    i++;
                }
                broj++;
            }
        }

    }
}
