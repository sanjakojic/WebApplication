﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppArrayAndString
{
    public class PrebrojavanjeZnakova
    {
        public static int Prebroj(string s)
        {
            int brojac = 0;

            if (s.Contains("a"))
            {
                brojac++;
            }

            return brojac;
        }

    }
}
