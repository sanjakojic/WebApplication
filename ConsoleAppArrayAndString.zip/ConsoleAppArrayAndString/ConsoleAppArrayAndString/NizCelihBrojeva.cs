﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppArrayAndString
{
    public class NizCelihBrojeva
    {
        public int[] NizCelih;
        public int Brojac;

        public NizCelihBrojeva(int kapacitet)
        {
            NizCelih = new int[kapacitet];
            Brojac = 0;
        }

        public void DodajElement(int broj)
        {
            if (NizCelih.Length > Brojac)
            {
                NizCelih[Brojac] = broj;
                Brojac++;
            }
            else
            {
                Console.WriteLine("Greska! Niz je popunjen, ne moze da se doda novi element.");
            }
        }


        public int SaberiPrviIPoslednjiCeoNiz()
        {
            if (Brojac > 0)
            {
                int rezultat;
                rezultat = NizCelih[0] + NizCelih[NizCelih.Length-1];
                return rezultat;
            }
            else
            {
                Console.WriteLine("Niz je prazan.");
                return 0;
            }
        }

        public int SaberiPrviIPoslednjiPopunjen()
        {
            int rezultat = 0;

            if (Brojac > 0)
            {
                rezultat = NizCelih[0] + NizCelih[Brojac - 1];
                return rezultat;
            }
            else
            {
                Console.WriteLine("Niz je prazan.");
                return rezultat;
            }
        }


        public int SaberiPozitivne()
        {
            int zbir = 0;
            for (int i = 0; i < Brojac; i++)
            {
                if (NizCelih[i] > 0)
                {
                    zbir = zbir + NizCelih[i];
                }
            }
            return zbir;
        }


        public int PomnoziNegativne()
        {
            int proizvod = 1;
            for (int i = 0; i < Brojac; i++)
            {
                if (NizCelih[i] < 0)
                {
                    proizvod = proizvod * NizCelih[i];
                }
            }
            return proizvod;
        }


        public int BrojPonavljanja(int broj)
        {
            int brojPonavljanja = 0;
            for (int i = 0; i < Brojac; i++)
            {
                if (NizCelih[i] == broj)
                {
                    brojPonavljanja++;
                }
            }
            return brojPonavljanja;
        }

        public void IspisiParne()
        {
            for (int i = 0; i < Brojac; i++)
            {
                if (NizCelih[i] % 2 == 0)
                {
                    Console.Write(NizCelih[i] + " ");
                }
            }
        }

        public void IspisiDeljiveSa5()
        {
            for (int i = 0; i < Brojac; i++)
            {
                if (NizCelih[i] % 5 == 0)
                {
                    Console.Write(NizCelih[i] + " ");
                }
            }
        }


        public void IspisiObrnuto()
        {
            for (int i = Brojac-1; i >= 0; i--)
            {
                Console.WriteLine(NizCelih[i]);
            }
        }

    }
}
