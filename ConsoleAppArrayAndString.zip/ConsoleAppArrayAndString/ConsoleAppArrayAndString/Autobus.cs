﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppArrayAndString
{
    public class Autobus
    {
        public bool[] sedista = new bool[50];

        public Autobus()
        {
            for (int i = 0; i < sedista.Length; i++)
            {
                sedista[i] = true;
            }
        }

        public void UvediPutnika(int brojSedista)
        {
            if (sedista[brojSedista] == true)
            {
                sedista[brojSedista] = false;
            }
            else
            {
                Console.WriteLine("Sediste je vec zauzeto.");
            }
        }

        public bool ImaLiSlobodnihMesta()
        {
            for (int i = 0; i < sedista.Length; i++)
            {
                if (sedista[i] == true) 
                {
                    return true;
                }
            }
            return false;
        }


        public int VratiSLobodnaMesta()
        {
            int brojSlobodnih = 0;
            for (int i = 0; i < sedista.Length; i++)
            {
                if (sedista[i] == true)
                {
                    brojSlobodnih++;
                }
            }
            return brojSlobodnih;
        }


        public int VratiZauzetihMesta()
        {
            int brojZauzetih = 0;
            for (int i = 0; i < sedista.Length; i++)
            {
                if (sedista[i] == false)
                {
                    brojZauzetih++;
                }
            }
            return brojZauzetih;
        }

        public void IspisiStatus()
        {
            for (int i = 0; i < sedista.Length; i++)
            {
                if (sedista[i] == true)
                {
                    Console.WriteLine("Sediste broj " + i + " je slobodno.");
                }
                else
                {
                    Console.WriteLine("Sediste broj " + i + " je zauzeto.");
                }
            }
        }

    }
}
