﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppArrayAndString
{
    public class Program
    {
        static void Main(string[] args)
        {
            //NizCelihBrojeva niz1 = new NizCelihBrojeva(3);
            //NizCelihBrojeva niz2 = new NizCelihBrojeva(5);
            //NizCelihBrojeva niz3 = new NizCelihBrojeva(10);

            //niz1.DodajElement(1);
            //niz1.DodajElement(-1);
            //niz1.DodajElement(3);

            //niz2.DodajElement(34);
            //niz2.DodajElement(45);

            //niz3.DodajElement(56);
            //niz3.DodajElement(67);
            //niz3.DodajElement(-89);

            //int zbir = niz1.SaberiPrviIPoslednjiPopunjen();
            //Console.WriteLine("Zbir prvog i poslednjeg: " + zbir);

            //niz2.IspisiObrnuto();

            //niz3.IspisiObrnuto();

            //int proizvod = niz3.PomnoziNegativne();
            //Console.WriteLine("Proizvod negativnih: " + proizvod);

            //niz2.IspisiDeljiveSa5();


            //Autobus autobus = new Autobus();
            //autobus.UvediPutnika(0);
            //autobus.UvediPutnika(19);
            //autobus.UvediPutnika(49);

            //autobus.IspisiStatus();

            //string ime = "Pera";
            //char[] nizKaraktera = new char[5];

            //string prezime = new string(nizKaraktera);

            //string s1 = "Danas ";
            //string s2 = "je lep dan.";
            //string s3 = s1 + s2;

            //int temperatura = 15;

            //string s4 = "Napolju je " + temperatura + " stepeni";

            //string s5 = "" + 12 + 15;

            //string s11 = "Recenica 1";
           
            //string s12 = "Recenica 1";

            //if (s11.Equals("HAHHAH"))
            //{
            //    Console.WriteLine("Isti");
            //}
            //else
            //{
            //    Console.WriteLine("Nisu isti");
            //}

            //Console.WriteLine(s5);


            int rezultat = PrebrojavanjeZnakova.Prebroj("paralelogram");

            Console.WriteLine(rezultat);

            Console.ReadLine();
        }
    }
}
