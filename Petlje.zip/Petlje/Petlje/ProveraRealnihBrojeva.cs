﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petlje
{
    public class ProveraRealnihBrojeva
    {
        public bool ManjiOdPi(double x)
        {
            if (x < 3.14)
            {
                Console.WriteLine("Broj je manji od pi.");
                return true;
            }
            else
            {
                Console.WriteLine("Broj je veci od pi.");
                return false;
            }
        }


        public bool ProveraRaspona(double broj)
        {
            if ((broj >= 100) && (broj <= 200))
            {
                Console.WriteLine("Broj je u rasponu.");
                return true;
            }
            else
            {
                Console.WriteLine("Broj nije u rasponu.");
                return false;
            }
        }


        public bool ProveraRasponaIli(double broj)
        {
            if ((broj < 0) || (broj > 33.3))
            {
                Console.WriteLine("Broj je u rasponu.");
                return true;
            }
            else
            {
                Console.WriteLine("Broj nije u rasponu.");
                return false;
            }
        }
    }
}
