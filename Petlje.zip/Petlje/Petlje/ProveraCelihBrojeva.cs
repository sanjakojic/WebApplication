﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petlje
{
    public class ProveraCelihBrojeva
    {
        public void ProveriZnak(int broj)
        {
            if (broj > 0)
            {
                Console.WriteLine("Broj: " + broj + " je veci od nule.");
            }
            if (broj < 0)
            {
                Console.WriteLine("Broj: " + broj + " je manji od nule.");
            }
            if (broj == 0)
            {
                Console.WriteLine("Broj: " + broj + " je jednak nuli.");
            }
        }

        public void ProveriVeceManjeJednako(int a, int b)
        {
            if (a > b)
            {
                Console.WriteLine("Broj " + a + " je veci od broja " + b);
            }
            if (a < b)
            {
                Console.WriteLine("Broj " + a + " je manji od broja " + b);
            }
            if (a == b)
            {
                Console.WriteLine("Broj " + a + " je jednak broju " + b);
            }
        }

        public bool Razlicito(int a, int b)
        {
            if (a != b)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public bool ProveraParnosti(int c)
        {
            if ((c % 2) == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
