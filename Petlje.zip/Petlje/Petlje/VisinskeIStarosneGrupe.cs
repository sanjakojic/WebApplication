﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petlje
{
    public class VisinskeIStarosneGrupe
    {

        public void ProveriVisinu(double visina)
        {
            if ((visina < 120) || (visina > 240))
            {
                Console.WriteLine("Greska!");
            }
            else
            {
                if (visina <= 158)
                {
                    Console.WriteLine("Osoba je niska.");
                }
                if ((visina > 158) && (visina <= 179))
                {
                    Console.WriteLine("Osoba je srednje visoka.");
                }
                if (visina > 179)
                {
                    Console.WriteLine("Osoba je visoka.");
                }
            }
        }


        public void ProveriStarosnoDoba(int godine)
        {
            if ((godine <= 30) && (godine > 0))
            {
                Console.WriteLine("Osoba je mlada.");
            }
            else if ((godine > 30) && (godine <= 55))
            {
                    Console.WriteLine("Osoba je srednjeg doba.");
            }
            else if ((godine > 55) && (godine < 120))
            {
                Console.WriteLine("Osoba je stara.");
            }
            else
            {
                Console.WriteLine("Greska!");
            }
        }

    }
}
