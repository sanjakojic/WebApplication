﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petlje
{
    public class TelevizorDva
    {
        public int JacinaTona = 0;
        public int TrenutniProgram = 1;
        public bool Ukljucen = false;

        public void Ukljuci()
        {
            if (!Ukljucen)
            {
                Ukljucen = true;
            }
            else
            {
                Console.WriteLine("Televizor je vec ukljucen!");
            }
        }


        public void Iskljuci()
        {
            if (Ukljucen)
            {
                Ukljucen = false;
            }
            else
            {
                Console.WriteLine("Televizor je vec iskljucen!");
            }
        }

        public void PojacajTon()
        {
            if (JacinaTona < 10)
            {
                JacinaTona = JacinaTona + 1;
            }
            else
            {
                Console.WriteLine("Televizor je vec na maksimumu!");
            }
        }


        public void SmanjiTon()
        {
            if (JacinaTona > 0)
            {
                JacinaTona = JacinaTona - 1;
            }
            else
            {
                Console.WriteLine("Televizor je vec na minimumu!");
            }
        }

        public void PromeniProgramNavise()
        {
            if (TrenutniProgram < 99)
            {
                TrenutniProgram = TrenutniProgram + 1;
            }
            else
            {
                TrenutniProgram = 1;
            }
        }


        public void PromeniProgramNanize()
        {
            if (TrenutniProgram > 1)
            {
                TrenutniProgram = TrenutniProgram - 1;
            }
            else
            {
                TrenutniProgram = 99;
            }
        }


        public void IspisiParametre()
        {
            if (Ukljucen)
            {
                Console.WriteLine("Trenutni program: " + TrenutniProgram);
                Console.WriteLine("Jacina tona: " + JacinaTona);
            }
            else
            {
                Console.WriteLine("Televizor je iskljucen!");
            }
        }


    }
}
