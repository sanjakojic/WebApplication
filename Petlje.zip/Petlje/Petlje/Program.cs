﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petlje
{
    public class Program
    {
        static void Main(string[] args)
        {
            //ProveraCelihBrojeva provera = new ProveraCelihBrojeva();
            //provera.ProveriZnak(-12);
            //provera.ProveriZnak(0);
            //provera.ProveriZnak(144);

            //provera.ProveriVeceManjeJednako(10,5);
            //provera.ProveriVeceManjeJednako(5, 5);
            //provera.ProveriVeceManjeJednako(1, 5);

            //bool rezultat = provera.ProveraParnosti(8);
            //if (rezultat) //if(rezultat == true)
            //{
            //    Console.WriteLine("Broj je paran.");
            //}
            //else
            //{
            //    Console.WriteLine("Broj je neparan.");
            //}

            //bool result = provera.Razlicito(10, 15);
            //if (result)
            //{
            //    Console.WriteLine("Brojevi su razliciti.");
            //}
            //else
            //{
            //    Console.WriteLine("Brojevi nisu razliciti.");
            //}

            //ProveraRealnihBrojeva realni = new ProveraRealnihBrojeva();
            //realni.ManjiOdPi(7.12333);            

            //realni.ProveraRaspona(125.15699);
            //realni.ProveraRaspona(200.00000001);

            //realni.ProveraRasponaIli(-5);
            //realni.ProveraRasponaIli(17.33);
            //realni.ProveraRasponaIli(34.33);

            //VisinskeIStarosneGrupe grupe = new VisinskeIStarosneGrupe();
            //grupe.ProveriVisinu(171);

            TelevizorDva tv = new TelevizorDva();
            tv.PojacajTon();
            tv.IspisiParametre();

            tv.Iskljuci();
            tv.IspisiParametre();

            tv.PromeniProgramNanize();
            tv.IspisiParametre();

            tv.Ukljuci();
            tv.PojacajTon();
            tv.PromeniProgramNavise();
            tv.IspisiParametre();

            Console.ReadLine();

        }
    }
}
