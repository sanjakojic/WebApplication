﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace JsonParsingApp
{
    public class User
    {
        private string userName;
        private bool enabled;

        [JsonConstructor]
        public User(string userName, bool enabled)
        {
            this.userName = userName;
            this.enabled = enabled;
        }

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

        public bool Enabled
        {
            get { return enabled; }
            set { enabled = value; }
        }

        #region Overrides of Object

        /// <inheritdoc />
        public override string ToString()
        {
            return $"Username: {userName} isEnabled: {enabled}";
        }

        #endregion
    }
}
