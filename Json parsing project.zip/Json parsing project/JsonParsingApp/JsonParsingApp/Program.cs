﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace JsonParsingApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Example from web site
            //string json = @"{
            //    ""UserName"": ""sanjaK"",
            //    ""Enabled"": true
            //    }";

            //User user = JsonConvert.DeserializeObject<User>(json);

            //Console.WriteLine(user);


            //Parsing from file
            Person person = new Person();
            string jsonString = person.VratiJson();

            Person personFinal = JsonConvert.DeserializeObject<Person>(jsonString);

            //Console.WriteLine(personFinal);

            //List<Person> listaOsoba = person.VratiListuPersona();

            //string json = JsonConvert.SerializeObject(listaOsoba, Formatting.Indented);

            //bool result = person.UpisiUFile(json);

            //if (result)
            //{
            //    Console.WriteLine("Uspesno ste upisali json.");
            //}
            //else
            //{
            //    Console.WriteLine("Json nije upisan.");
            //}

            string s = person.VratiHeroje();

            List<Person> listaHeroja = JsonConvert.DeserializeObject<List<Person>>(s);
            Console.WriteLine("Heroji:");
            foreach (var item in listaHeroja)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();
        }
    }
}
