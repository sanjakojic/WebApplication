﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace JsonParsingApp
{
    public class Person
    {
        private int id;
        private string name;
        private string surname;
        private string address;
        private string phone;

        public Person() {}

        [JsonConstructor]
        public Person(int id, string name, string surname, string address, string phone)
        {
            this.id = id;
            this.name = name;
            this.surname = surname;
            this.address = address;
            this.phone = phone;
        }

        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }
        public string Address { get => address; set => address = value; }
        public string Phone { get => phone; set => phone = value; }

        public bool UpisiUFile(string json)
        {
            bool daLiJeUpisano = false;
            string path = @"C:\Users\sanja.kojic\Desktop\heroji.txt";

            using (StreamWriter sr = File.AppendText(path))
            {
                sr.Write(json);
                sr.Close();
                daLiJeUpisano = true;
            }
            return daLiJeUpisano;
        }

        #region Overrides of Object

        /// <inheritdoc />
        public override string ToString()
        {
            return $"Name: {name}, Surname: {surname}, Address: {address}, Phone number: {phone}";
        }

        #endregion


        public string VratiJson()
        {
            string s = string.Empty;
            string path = @"C:\Users\sanja.kojic\Desktop\jsonFile.txt";

            using (StreamReader sr = File.OpenText(path))
            {
                 s = sr.ReadToEnd();
            }

            return s;
        }

        public string VratiHeroje()
        {
            string s = string.Empty;
            string path = @"C:\Users\sanja.kojic\Desktop\heroji.txt";

            using (StreamReader sr = File.OpenText(path))
            {
                s = sr.ReadToEnd();
            }

            return s;
        }

        public List<Person> VratiListuPersona()
        {
            List<Person> lista = new List<Person>();

            lista.Add(new Person()
            {
                id = 111,
                name = "Zivojin",
                surname = "Misic",
                address = "Kneza Milosa 17",
                phone = "+381601233210"
            });

            lista.Add(new Person()
            {
                id = 222,
                name = "Stepa",
                surname = "Stepanovic",
                address = "Kneza Milosa 18",
                phone = "+381639877895"
            });

            lista.Add(new Person()
            {
                id = 333,
                name = "Radomir",
                surname = "Putnik",
                address = "Knjeginje Ljubice 125",
                phone = "+381643699630"
            });


            return lista;
        }

    }
}
