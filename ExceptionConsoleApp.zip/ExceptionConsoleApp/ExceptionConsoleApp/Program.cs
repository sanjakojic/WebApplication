﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExceptionConsoleApp.Exception;
using ExceptionConsoleApp.InterfaceExample;

namespace ExceptionConsoleApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Prodavnica prodavnica = new Prodavnica();
            //Skladiste skladiste = new Skladiste();
            //Dobavljac dobavljac = new Dobavljac();

            //prodavnica.Ispisi();
            
            //dobavljac.IzvrsiIsporuku(prodavnica, 100);
            //dobavljac.IzvrsiIsporuku(skladiste, 500);

            //prodavnica.Ispisi();

            //IzuzeciDemo demo = new IzuzeciDemo();
            //demo.Ispisi();

            //Console.WriteLine("11 element je ispisan.");

            Osoba o = new Osoba();
            string ime = "Pera";
            string prezime = "Mitic";

            //o.SetIme(ime);
            //o.SetPrezime(prezime);

            Console.ReadLine();
        }
    }
}
