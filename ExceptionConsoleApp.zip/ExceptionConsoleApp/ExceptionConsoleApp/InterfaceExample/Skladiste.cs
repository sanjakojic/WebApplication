﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionConsoleApp.InterfaceExample
{
    public class Skladiste : ISluzbaNabavke
    {
        private int StanjeNaSkladistu = 1000;

        public void DodajRobu(int BrojKomada)
        {
            if (BrojKomada > 0)
            {
                StanjeNaSkladistu += BrojKomada;
            }
            else
            {
                Console.WriteLine("Greska, broj komada mora biti veci od nule.");
            }
        }

        public void SkiniSaStanja(int BrojKomada)
        {
            if (BrojKomada > 0 && BrojKomada <= StanjeNaSkladistu)
            {
                StanjeNaSkladistu -= BrojKomada;
            }
            else
            {
                Console.WriteLine("Broja komada je manji od nule/nema dovoljno na stanju.");
            }
        }
    }
}
