﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionConsoleApp.InterfaceExample
{
    public class Prodavnica : ISluzbaNabavke, ISluzbaProdaje
    {
        private int BrojKomadaProizvoda = 0;

        public void DodajRobu(int BrojKomada)
        {
            if (BrojKomada > 0)
            {
                BrojKomadaProizvoda += BrojKomada;
            }
            else
            {
                Console.WriteLine("Greska, broj proizvoda mora biti veci od nule.");
            }
        }

        public void ProdajRobu(int BrojKomada)
        {
            if (BrojKomada > 0 && BrojKomadaProizvoda >= BrojKomada)
            {
                BrojKomadaProizvoda -= BrojKomada;
            }
            else
            {
                Console.WriteLine("Greska, nema dovoljno proizvoda.");
            }
        }

        public void Ispisi()
        {
            Console.WriteLine($"Broj proizvoda u prodavnici je: {BrojKomadaProizvoda}");
        }
    }
}
