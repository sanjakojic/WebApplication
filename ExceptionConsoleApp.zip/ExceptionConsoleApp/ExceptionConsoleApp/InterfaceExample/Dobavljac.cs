﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionConsoleApp.InterfaceExample
{
    public class Dobavljac
    {
        public void IzvrsiIsporuku(ISluzbaNabavke sluzbaNabavke, int BrojKomada)
        {
            sluzbaNabavke.DodajRobu(BrojKomada);
        }
    }
}
