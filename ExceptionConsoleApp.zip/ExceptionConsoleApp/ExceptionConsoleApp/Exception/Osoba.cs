﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionConsoleApp.Exception
{
    public class Osoba
    {
        private string Ime;
        private string Prezime;



        public void SetIme(string Ime)
        {
            if (Ime == null)
            {
                throw new ArgumentNullException("Ime je null");
            }

            this.Ime = Ime;
        }

        public string GetIme()
        {
            return Ime;
        }

        public void SetPrezime(string Prezime)
        {
            if (Prezime == null)
            {
                throw new ArgumentNullException("Prezime je null");
            }

            this.Prezime = Prezime;
        }

        public string GetPrezime()
        {
            return Prezime;
        }
    }
}
