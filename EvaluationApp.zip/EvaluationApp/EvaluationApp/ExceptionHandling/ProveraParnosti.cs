﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationApp.ExceptionHandling
{
    public class ProveraParnosti
    {
        public static bool Parnost(int a)
        {
            if (a == 0)
            {
                throw new ArgumentException("Broj je 0.");
            }

            if (a % 2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
