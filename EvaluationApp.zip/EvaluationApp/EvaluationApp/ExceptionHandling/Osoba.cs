﻿using System;

namespace EvaluationApp.ExceptionHandling
{
    public class Osoba
    {
        #region Attributes

        private string ime;
        private string prezime;
        private int visina;
        private double tezina;
        private int godine;

        #endregion

        #region Get and Set methods

        public string Ime
        {
            get { return ime; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("Ime je null.");
                }

                ime = value;
            }
        }

        public string Prezime
        {
            get { return prezime; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("Prezime je null.");
                }

                prezime = value;
            }
        }

        public int Visina
        {
            get { return visina; }
            set
            {
                if (value <= 50 || value > 250)
                {
                    throw new ArgumentOutOfRangeException("Visina je van opsega.");
                }

                visina = value;
            }
        }


        public double Tezina
        {
            get { return tezina; }
            set
            {
                if (value < 2 || value > 250)
                {
                    throw new ArgumentOutOfRangeException("Tezina je van granica.");
                }

                tezina = value;
            }
        }


        public int Godine
        {
            get { return godine; }
            set
            {
                if (value < 0 || value > 125)
                {
                    throw new ArgumentOutOfRangeException("Godine su van granica.");
                }

                godine = value;
            }
        }

        #endregion

        #region ToString method

        public override string ToString()
        {
            return $"Ime: {ime}, Prezime: {prezime}, Visina: {visina}, Tezina: {tezina}, Godine: {godine}";
        }

        #endregion

    }
}
