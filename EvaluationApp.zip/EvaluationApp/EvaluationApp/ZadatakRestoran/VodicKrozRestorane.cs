﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationApp.ZadatakRestoran
{
    public class VodicKrozRestorane
    {
        private List<Restoran> listaRestorana;

        public VodicKrozRestorane()
        {
            listaRestorana = new List<Restoran>();
        }

        public void DodajNaPocetak(Restoran restoran)
        {
            listaRestorana.Insert(0, restoran);
        }

        public void IspisiRestoraneSaOcenom(int ocena)
        {
            foreach (var item in listaRestorana)
            {
                if (item.Ocena == ocena)
                {
                    Console.WriteLine(item.Naziv);
                }
            }
        }


        public List<Restoran> ObrisiLoseRestorane()
        {
            foreach (var item in listaRestorana)
            {
                if (item.Ocena == 1)
                {
                    listaRestorana.Remove(item);
                }
            }

            return listaRestorana;
        }
    }
}
