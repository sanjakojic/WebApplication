﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationApp.ZadatakRestoran
{
    public class VodicKrozRestorane
    {
        private List<Restoran> listaRestorana;

        public VodicKrozRestorane()
        {
            listaRestorana = new List<Restoran>();
        }

        public void DodajNaPocetak(Restoran restoran)
        {
            listaRestorana.Insert(0, restoran);
        }

        public void IspisiRestoraneSaOcenom(int ocena)
        {
            foreach (var item in listaRestorana)
            {
                if (item.Ocena == ocena)
                {
                    Console.WriteLine(item.Naziv);
                }
            }
        }

        //Prvi nacin
        public List<Restoran> ObrisiLoseRestoraneLista()
        {
           List<Restoran> dobri = new List<Restoran>();
            foreach (var item in listaRestorana)
            {
                if (item.Ocena > 1)
                {
                    dobri.Add(item);
                }
            }

            return dobri;
        }


        //Drugi nacin
        public List<Restoran> ObrisiLoseRestoraneFor()
        {
            for (int i = listaRestorana.Count-1; i >= 0; i--)
            {
                if (listaRestorana[i].Ocena == 1)
                {
                    listaRestorana.Remove(listaRestorana[i]);
                }
            }
            return listaRestorana;
        }

    }
}
