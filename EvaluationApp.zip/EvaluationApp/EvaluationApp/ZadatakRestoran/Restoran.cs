﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationApp.ZadatakRestoran
{
    public class Restoran
    {
        #region Attributes

        private string naziv;
        private int ocena;

        #endregion

        #region Get and Set methods

        public string Naziv
        {
            get { return naziv; }
            set
            {
                // if(string.IsNullOrEmpty(value))
                if (value == null || value.Equals(string.Empty))
                {
                    throw new ArgumentException("Ime null ili empty string.");
                }

                naziv = value;
            }
        }

        public int Ocena
        {
            get { return ocena; }
            set
            {
                if (value < 1 || value > 5)
                {
                    throw new Exception("Greska,ocena nije u rasponu.");
                }

                ocena = value;
            }
        }

        #endregion

    }
}
