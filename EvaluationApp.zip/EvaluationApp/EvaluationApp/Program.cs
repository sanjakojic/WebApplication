﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EvaluationApp.ExceptionHandling;
using EvaluationApp.Zadatak1;
using EvaluationApp.ZadatakRestoran;

namespace EvaluationApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Osoba o = new Osoba();
            //o.Ime = "Mikica";
            //o.Prezime = "Leposavic";
            //o.Visina = 212;
            //o.Tezina = 100.25;
            //o.Godine = 28;

            //Console.WriteLine(o.ToString());

            //try
            //{
            //    Console.WriteLine(ProveraParnosti.Parnost(0));
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e);
            //}

            //MuzickiStub stub = new MuzickiStub();
            //stub.Ukljuci();
            //stub.PojacajTon();
            //stub.PojacajTon();
            //stub.PromeniStanicu(88.9);
            //stub.Ispisi();

            Restoran r1 = new Restoran();
            r1.Naziv = "Blue Hill";
            r1.Ocena = 4;

            Restoran r2 = new Restoran();
            r2.Naziv = "Per Se";
            r2.Ocena = 1;

            Restoran r3 = new Restoran();
            r3.Naziv = "Daniel";
            r3.Ocena = 4;

            VodicKrozRestorane vodic = new VodicKrozRestorane();
            vodic.DodajNaPocetak(r1);
            vodic.DodajNaPocetak(r2);
            vodic.DodajNaPocetak(r3);

            vodic.IspisiRestoraneSaOcenom(4);

            List<Restoran> listaBezLosih = vodic.ObrisiLoseRestorane();
            foreach (var item in listaBezLosih)
            {
                Console.WriteLine(item.ToString());
            }

            Console.ReadLine();
        }
    }
}
