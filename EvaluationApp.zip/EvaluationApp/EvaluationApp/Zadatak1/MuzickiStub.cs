﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationApp.Zadatak1
{
    public class MuzickiStub : MuzickiUredjaj, IRadioKomponenta, ICDKomponenta
    {
        #region Attributes

        private double fmFrekvencija = 87.5;
        private int brojPesme;
        private bool ukljucenRadio;
        private bool ukljucenCd;

        #endregion

        public override void Ispisi()
        {
            if (ukljucen)
            {
                Console.WriteLine("Muzicki stub je ukljucen.");
                Console.WriteLine("Jacina tona je: " + jacinaTona);

                if (ukljucenRadio)
                {
                    Console.WriteLine("Radio je ukljucen, frekvencija je: " + fmFrekvencija);
                } 

                if (ukljucenCd)
                {
                    Console.WriteLine("CD je ukljucen, broj pesme je: " + brojPesme);
                }
            }
            else
            {
                Console.WriteLine("Uredjaj je iskljucen.");
            }
        }

        public void PromeniStanicu(double frekvencija)
        {
            ukljucenRadio = true;
            ukljucenCd = false;
            if (frekvencija > 87.5 && frekvencija <= 108)
            {
                fmFrekvencija = frekvencija;
            }
            else
            {
                fmFrekvencija = 87.5;
            }
        }

        public void PustiPesmu(int brojPesme)
        {
            ukljucenRadio = false;
            ukljucenCd = true;
            if (brojPesme > 0 && brojPesme <= 21)
            {
                this.brojPesme = brojPesme;
            }
            else
            {
                this.brojPesme = 1;
            }
        }



    }
}
