﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationApp.Zadatak1
{
    public abstract class MuzickiUredjaj
    {
        #region Attributes

        protected bool ukljucen;
        protected int jacinaTona = 0;

        #endregion

        #region Public Methods

        public void Ukljuci()
        {
            ukljucen = true;
        }

        public void Iskljuci()
        {
            ukljucen = false;
        }

        public void PojacajTon()
        {
            if (jacinaTona < 40)
            {
                jacinaTona++;
            }
        }

        public void SmanjiTon()
        {
            if (jacinaTona > 0)
            {
                jacinaTona--;
            }
        }

        #endregion

        #region Abstract Methods

        public abstract void Ispisi();

        #endregion

    }
}
