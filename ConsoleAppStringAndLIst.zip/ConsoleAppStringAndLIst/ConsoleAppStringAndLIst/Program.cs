﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppStringAndLIst
{
    class Program
    {
        static void Main(string[] args)
        {
            AnalizatorTeksta tekst1 = new AnalizatorTeksta();
            AnalizatorTeksta tekst2 = new AnalizatorTeksta("Danas je lep dan.");

            //tekst1.SetTekst("Nebo je plavo.");
            //tekst1.DodajNaKraj("Sunce sija.");

            //tekst2.ProveriJednakost("lep dan");

            //Console.WriteLine(tekst1.GetTekst());
            //Console.WriteLine(tekst2.GetTekst());

            //tekst2.SetTekst("Mrak");
            //tekst2.LeksikografskaProvera("Dan");

            //tekst2.SetTekst("Dan");
            //tekst2.LeksikografskaProvera("Abba");

            //tekst2.SetTekst("Ana");
            //tekst2.LeksikografskaProvera("Anb");


            //string rec = BrojacReci.NajcescaRec("Danas je lep dan. Jako lep dan. Ja volim ovaj lep dan. Dan.");
            //Console.WriteLine(rec);

            int brojac = 0;
            int[] nizCelihBrojeva = new int[]
            {
                1,
                2,
                3,
                55,
                8,
                -4,
                0,
                -5
            };

            foreach (var item in nizCelihBrojeva)
            {
                Console.WriteLine("Broj: " + item + ",Index: " + brojac);
                brojac++;
            }

            List<string> voce = new List<string>();
            voce.Add("Jabuka");
            voce.Add("Ananas");
            voce.Add("Tresnja");
            voce.Add("Mango");
            voce.Add("Jagoda");

            foreach (var item in voce)
            {
                Console.WriteLine(item);
            }


            List<string> povrce = new List<string>()
            {
                "Paprika",
                "Paradajz"
            };
            
            string[] povrcke = new string[]
            {
                "Luk",
                "Spanac",
                "Krastavac"
            };

            povrce.AddRange(povrcke);

            Console.ReadLine();
        }
    }
}
