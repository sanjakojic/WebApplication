﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppStringAndLIst
{
    public class AnalizatorTeksta
    {
        public string Tekst;

        public AnalizatorTeksta()
        {
            Tekst = "nepoznat";
        }

        public AnalizatorTeksta(string noviTekst)
        {
            if (noviTekst != null)
            {
                Tekst = noviTekst;
            }
            else
            {
                Tekst = "nepoznat";
                Console.WriteLine("Tekst koji ste uneli je prazan.");
            }

        }


        public string GetTekst()
        {
            return Tekst;
        }


        public void SetTekst(string novi)
        {
            if (novi != null)
            {
                Tekst = novi;
            }
            else
            {
                Console.WriteLine("Tekst koji ste uneli je null.");
            }
        }


        public void DodajNaKraj(string s)
        {
            if (s != null)
            {
                if (Tekst.Equals("nepoznat"))
                {
                    Tekst = s;
                }
                else
                {
                    Tekst = Tekst + s;
                }
            }
            else
            {
                Console.WriteLine("Greska.");
            }
        }


        public void DodajNaPocetak(string noviTekst)
        {
            if (Tekst == null)
            {
                Console.WriteLine("Ulazni tekst je null");
            }
            else if (Tekst.Equals("nepoznat"))
            {
                Tekst = noviTekst;
            }
            else
            {
                Tekst = noviTekst + Tekst;
            }
        }


        public void ProveriJednakost(string noviTekst)
        {
            if (Tekst.Equals(noviTekst))
            {
                Console.WriteLine("Tekstovi su jednaki.");
            }
            else
            {
                Console.WriteLine("Tekstovi su razliciti.");
            }
        }

        public void ProveriTekst(string s)
        {
            if (Tekst.ToLower().Equals(s.ToLower()))
            {
                Console.WriteLine("Tekstovi su isti.");
            }
            else
            {
                Console.WriteLine("Tekstovi su razliciti.");
            }
        }

        public void LeksikografskaProvera(string noviTekst)
        {
            if (String.Compare(Tekst, noviTekst) < 0)
            {
                Console.WriteLine("Tekst je pre novog teksta.");
            }
            if (String.Compare(Tekst, noviTekst) == 0)
            {
                Console.WriteLine("Tekst je jednak novom tekstu.");
            }
            if(String.Compare(Tekst, noviTekst) > 0)
            {
                Console.WriteLine("Tekst je posle novog teksta.");
            }
        }


    }
}
