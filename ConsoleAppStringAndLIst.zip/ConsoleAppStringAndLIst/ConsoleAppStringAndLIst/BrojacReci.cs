﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppStringAndLIst
{
    public class BrojacReci
    {
        public static int BrojReciUTekstu(string tekst)
        {
            int brojReci = tekst.Split(' ').Length;
            return brojReci;
        }

        public static int PojavljivanjeReci(string s)
        {
            int brojac = 0;
            string[] reci = s.Split(' ');
            for (int i = 0; i < reci.Length; i++)
            {
                if (reci[i].ToLower().Equals("lep"))
                {
                    brojac++;
                }
            }
            return brojac;
        }


        public static int BrojPojavljivanjaReci(string tekst, string rec)
        {
            string[] reci = tekst.Split(' ');
            int brojac = 0;

            for (int i = 0; i < reci.Length; i++)
            {
                if (reci[i].ToLower().Equals(rec.ToLower()) || reci[i].ToLower().Equals(rec.ToLower() + "."))
                {
                    brojac++;
                }
            }
            return brojac;
        }


        public static string NajcescaRec(string tekst)
        {
            string[] reci = tekst.Split(' ');
            int maxBrojPonavljanja = 1;
            string recMax = reci[0];

            for (int i = 0; i < reci.Length; i++)
            {
                if (BrojPojavljivanjaReci(tekst, reci[i]) > maxBrojPonavljanja)
                {
                    recMax = reci[i];
                    maxBrojPonavljanja = BrojPojavljivanjaReci(tekst, reci[i]);
                }
            }

            return recMax;
        }


    }
}
