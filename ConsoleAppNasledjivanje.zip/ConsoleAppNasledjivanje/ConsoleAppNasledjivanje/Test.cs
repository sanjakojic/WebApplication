﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleAppNasledjivanje.Enkapsulacija;
using ConsoleAppNasledjivanje.Liste;
using ConsoleAppNasledjivanje.Nasledjivanje;

namespace ConsoleAppNasledjivanje
{
    public class Test
    {
        static void Main(string[] args)
        {
            Knjiga knjiga1 = new Knjiga("Znakovi pored puta", "Ivo Andric");
            Knjiga knjiga2 = new Knjiga("Autobiografija", "Branislav Nusic");
            Knjiga knjiga3 = new Knjiga("Pop Cira i pop Spira", "Stevan Sremac");

            Biblioteka biblioteka = new Biblioteka();

            biblioteka.DodajKnjigu(knjiga1);
            biblioteka.DodajKnjigu(knjiga2);
            biblioteka.DodajKnjigu(knjiga3);

            List<Knjiga> listaPretrazenihKnjiga = biblioteka.PretraziKnjige("po");

            foreach (var item in listaPretrazenihKnjiga)
            {
                Console.WriteLine(item);
            }

            Osoba o = new Osoba();
            o.SetIme("Sanja");
            o.SetPrezime("Kojic");

            Console.WriteLine(o);


            NaucniKalkulator naucniKalkulator = new NaucniKalkulator();

            double obim = naucniKalkulator.IzracunajObimKruga(2.45);
            Console.WriteLine("Obim: " + obim);

            double povrsina = naucniKalkulator.IzracunajPovrsinuKruga(4.16);
            Console.WriteLine("Povrsina: " + povrsina);

            Osobe osoba = new Osobe("Pera", "Peric", "1234567890000");
            Djak djak = new Djak("Mika", "Lazic", "45685412301254", 5.0);
            Penzioner penzioner = new Penzioner("Zika", "Zikic", "4596103125485", 14500.23);

            osoba.Ispisi();
            djak.Ispisi();
            penzioner.IspisiBezJmbg();

            Console.ReadLine();
        }
    }
}
