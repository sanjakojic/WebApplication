﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppNasledjivanje
{
    public class Knjiga
    {
        public string Naziv;
        public string Autor;

        public Knjiga()
        {
            Naziv = "nepoznato";
            Autor = "nepoznato";
        }

        public Knjiga(string Naziv, string Autor)
        {
            this.Naziv = Naziv;
            this.Autor = Autor;
        }

        
        public override string ToString()
        {
            return "Naziv: " + Naziv + ", Autor: " + Autor;
        }

    }
}
