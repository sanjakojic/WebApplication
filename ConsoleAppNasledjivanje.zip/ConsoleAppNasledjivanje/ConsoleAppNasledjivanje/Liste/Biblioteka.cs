﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppNasledjivanje.Liste
{
    public class Biblioteka
    {
        public List<Knjiga> listaKnjiga;

        public Biblioteka()
        {
            listaKnjiga = new List<Knjiga>();
        }

        public void DodajKnjigu(Knjiga knjiga)
        {
            listaKnjiga.Add(knjiga);
        }


        public void DodajKnjige(List<Knjiga> knjige)
        {
            listaKnjiga.AddRange(knjige);
        }


        public bool DaLiPostoji(Knjiga knjiga)
        {
            if (listaKnjiga.Contains(knjiga))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public void ObrisiKnjigu(Knjiga knjiga)
        {
            if (listaKnjiga.Contains(knjiga))
            {
                listaKnjiga.Remove(knjiga);
            }
            else
            {
                Console.WriteLine("Knjiga se ne nalazi u biblioteci.");
            }
        }

        public List<Knjiga> PretraziKnjige(string naziv)
        {
            List<Knjiga> pretrazeneKnjige = new List<Knjiga>();

            foreach (var item in listaKnjiga)
            {
                if (item.Naziv.ToLower().Contains(naziv.ToLower()))
                {
                    pretrazeneKnjige.Add(item);
                }
            }
            return pretrazeneKnjige;
        }

    }
}
