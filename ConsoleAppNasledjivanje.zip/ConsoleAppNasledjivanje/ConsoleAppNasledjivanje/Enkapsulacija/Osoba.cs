﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppNasledjivanje.Enkapsulacija
{
    public class Osoba
    {
        private string Ime;
        private string Prezime;

        public Osoba()
        {}

        public string GetIme()
        {
            return Ime;
        }

        public void SetIme(string value)
        {
            Ime = value;
        }

        public string GetPrezime()
        {
            return Prezime;
        }

        public void SetPrezime(string value)
        {
            Prezime = value;
        }

        
        public override string ToString()
        {
            return "Ime: " + Ime + " Prezime: " + Prezime;
        }

    }
}
