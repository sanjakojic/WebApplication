﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppNasledjivanje.Nasledjivanje
{
    public class Osobe
    {
        protected string Ime = "N";
        protected string Prezime = "N";
        protected string Jmbg;

        public Osobe(string Ime, string Prezime, string Jmbg)
        {
            if (Ime != null && Prezime != null && Jmbg != null)
            {
                this.Ime = Ime;
                this.Prezime = Prezime;
                this.Jmbg = Jmbg;
            }
            else
            {
                Console.WriteLine("Greska! Atribut je null.");
            }
        }


        public virtual void Ispisi()
        {
            Console.WriteLine("Ime: " + Ime);
            Console.WriteLine("Prezime: " + Prezime);
            Console.WriteLine("Jmbg: " + Jmbg);
        }

        public virtual void IspisiBezJmbg()
        {
            Console.WriteLine("Ime: " + Ime);
            Console.WriteLine("Prezime: " + Prezime);
        }

    }
}
