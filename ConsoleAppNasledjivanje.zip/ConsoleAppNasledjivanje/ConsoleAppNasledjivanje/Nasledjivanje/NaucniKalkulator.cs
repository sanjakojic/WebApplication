﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppNasledjivanje.Nasledjivanje
{
    public class NaucniKalkulator : Kalkulator
    {
        public double IzracunajObimKruga(double poluprecnik)
        {
            double obimKruga = 0;
            obimKruga = 2 * poluprecnik * Pi;
            return obimKruga;
        }

        public double IzracunajPovrsinuKruga(double poluprecnik)
        {
            double povrsinaKruga = 0;
            povrsinaKruga = poluprecnik * poluprecnik * Pi;
            return povrsinaKruga;
        }
    }
}
