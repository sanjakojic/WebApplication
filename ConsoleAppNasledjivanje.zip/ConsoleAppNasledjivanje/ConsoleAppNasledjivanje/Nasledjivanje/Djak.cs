﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppNasledjivanje.Nasledjivanje
{
    public class Djak : Osobe
    {
        private double ProsecnaOcena;

        public Djak(string ime, string prezime, string jmbg, double prosecnaOcena) : base(ime, prezime, jmbg)
        {
            if(ime != null && prezime !=null && jmbg != null && (prosecnaOcena >=1 && prosecnaOcena<= 5))
            {
                ProsecnaOcena = prosecnaOcena;
            }
            else
            {
                Console.WriteLine("Greska.");
            }
        }

        public override void Ispisi()
        {
            base.Ispisi();
            Console.WriteLine("Prosecna ocena: " + ProsecnaOcena);
        }
    }
}
