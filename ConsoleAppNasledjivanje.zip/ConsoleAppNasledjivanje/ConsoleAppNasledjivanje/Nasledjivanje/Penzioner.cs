﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppNasledjivanje.Nasledjivanje
{
    public class Penzioner : Osobe
    {
        private double Penzija;

        public Penzioner(string Ime, string Prezime, string Jmbg, double Penzija) : base(Ime, Prezime, Jmbg)
        {
            if (Penzija > 0)
            {
                this.Penzija = Penzija;
            }
            else
            {
                Console.WriteLine("Greska.Penzija nije veca on 0.");
            }
        }

        public override void IspisiBezJmbg()
        {
            base.IspisiBezJmbg();
            Console.WriteLine("Penzija: " + Penzija);
        }


    }
}
