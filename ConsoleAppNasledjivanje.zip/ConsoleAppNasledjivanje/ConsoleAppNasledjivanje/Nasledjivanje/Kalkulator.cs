﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppNasledjivanje.Nasledjivanje
{
    public class Kalkulator
    {
        protected double Pi = 3.14;
        protected double E = 2.71;

        protected double Saberi(double a, double b)
        {
            double rezultat = a + b;
            return rezultat;
        }

        protected double Oduzmi(double a, double b)
        {
            double rezultat = a - b;
            return rezultat;
        }

        protected double Pomnozi(double a, double b)
        {
            double rezultat = a * b;
            return rezultat;
        }

        protected double Podeli(double a, double b)
        {
            double rezultat = a / b;
            return rezultat;
        }

    }
}
