﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statements
{
    public class StatickiKonvertorTemperature
    {
        public static double KonvertujCUF(double tempC)
        {
            double rezultatTempF = ((tempC * 9.0) / 5.0) + 32;

            return rezultatTempF;
        }

        public static double KonvertujFUC(double tempF)
        {
            double rezultatTempC = (tempF - 32) * (5.0 / 9.0);

            return rezultatTempC;
        }

    }
}
