﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statements
{
    public class Kalkulator
    {
        public int broj = 5;

        public static int Saberi(int a, int b)
        {
            int rezultat = a + b;
            return rezultat;
        }

        public static int Oduzmi(int a, int b)
        {
            int rezultat = a - b;
            return rezultat;
        }
    }
}
