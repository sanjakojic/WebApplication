﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statements
{
    public class Program
    {
        static void Main(string[] args)
        {
            //BMIKalkulator kalkulator = new BMIKalkulator();
            //double bmi = kalkulator.IzracunajBMI(1.71, 64);
            //kalkulator.IspisiBMIKategoriju(bmi);

            //Hotel.PreostaliBrojSoba = 5;

            //Console.WriteLine("Kapacitet hotela je: " + Hotel.PreostaliBrojSoba);

            //int rezultatZbir = Kalkulator.Saberi(4, 5);
            //int rezultatOduzimanje = Kalkulator.Oduzmi(10, 3);

            //Console.WriteLine("Zbir: " + rezultatZbir);
            //Console.WriteLine("Oduzimanje: " + rezultatOduzimanje);


            
            double rezultatFarenhajt = StatickiKonvertorTemperature.KonvertujCUF(0.0);
            Console.WriteLine("0C = " + rezultatFarenhajt + "F");

            double rezultatCelzijus = StatickiKonvertorTemperature.KonvertujFUC(41.0);
            Console.WriteLine("41F = " + rezultatCelzijus + "C");

            Console.ReadLine();
        }
    }
}
