﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statements
{
    public class BMIKalkulator
    {

        public double IzracunajBMI(double visina, double tezina)
        {
            if ((visina >= 1.20) && (visina <= 2.40) && (tezina > 30) && (tezina < 200))
            {
                double bmiRezultat = tezina / (visina * visina);
                return bmiRezultat;
            }
            else
            {
                Console.WriteLine("Greska, tezina i visina nisu u opsegu.");
                return 0.0;
            }
            
        }


        public void IspisiBMIKategoriju(double bmi)
        {
            if (bmi <= 15)
            {
                Console.WriteLine("Vas BMI je: " + bmi + " ,vi pripadate grupi: anoreksija.");
            }
            else if ((bmi > 15) && (bmi <= 18.5))
            {
                Console.WriteLine("Vas BMI je: " + bmi + " ,vi pripadate grupi: mrsavi.");
            }
            else if ((bmi > 18.5) && (bmi <= 25))
            {
                Console.WriteLine("Vas BMI je: " + bmi + " ,vi pripadate grupi: normalni.");
            }
            else if ((bmi > 25) && (bmi <= 30))
            {
                Console.WriteLine("Vas BMI je: " + bmi + " ,vi pripadate grupi: popunjeni.");
            }
            else if ((bmi > 30) && (bmi <= 40))
            {
                Console.WriteLine("Vas BMI je: " + bmi + " ,vi pripadate grupi: debeli.");
            }
            else
            {
                Console.WriteLine("Vas BMI je: " + bmi + " ,vi pripadate grupi: gojazni.");
            }

        }
    }
}
