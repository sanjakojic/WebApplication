﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnumConsoleApp.Eksponati;
using EnumConsoleApp.Eksponati.Skulpture;

namespace EnumConsoleApp.Galerija
{
    public class Galerija
    {
        #region Attributes

        private Eksponat[] eksponati;
        private int brojac;

        #endregion

        #region Constants

        private const string DateTimeFormat = "dd.MM.yyyy";
        private const string Bronza = "bronza";
        private const string Skulptura = "skulptura";

        #endregion

        public Galerija()
        {
            eksponati = new Eksponat[100];
            brojac = 0;
        }

        public void UnesiEksponat(Eksponat eksponat)
        {
            bool daLiSadrzi = DaLiSadrzi(eksponat);

            if (eksponati[brojac] == null && eksponat != null && 
                brojac < eksponati.Length && !daLiSadrzi)
            {
                eksponati[brojac] = eksponat;
                brojac++;
            }
            else
            {
                throw new Exception("Nije moguce uneti novi eksponat.");
            }
        }

        public void UvediPopust(double procenat)
        {
            DateTime pocetniDatum = new DateTime(2017, 01, 01);
            DateTime krajnjiDatum = new DateTime(2017, 12, 31);

            for (int i = 0; i < brojac; i++)
            {
                if (eksponati[i].DatumPrijema >= pocetniDatum &&
                    eksponati[i].DatumPrijema <= krajnjiDatum)
                {
                    eksponati[i].Cena = eksponati[i].Cena * (100 - procenat) / 100;
                    Console.WriteLine(eksponati[i]);
                }
            }
        }

        public Eksponat[] VratiNajskupljeEksponate()
        {
            Eksponat[] dvaNajskuplja = new Eksponat[2];

            Array.Sort(eksponati);
            Array.Reverse(eksponati);
            dvaNajskuplja[0] = eksponati[0];
            dvaNajskuplja[1] = eksponati[1];

            return dvaNajskuplja;
        }

        #region Helper methods - private

        private bool DaLiSadrzi(Eksponat eksponat)
        {
            for (int i = 0; i < brojac; i++)
            {
                if (eksponati[i].Equals(eksponat))
                {
                    return true;
                }
            }
            return false;
        }

        #endregion
    }
}
