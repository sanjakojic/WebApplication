﻿
namespace EnumConsoleApp.Eksponati.Skulpture
{
    public class Skulptura : Eksponat
    {
        #region Attributes

        private string materijal;

        #endregion

        #region Get and Set

        public string Materijal
        {
            get { return materijal; }
            set { materijal = value; }
        }

        #endregion

        #region Overrides of Eksponat

        public override string ToString()
        {
            return base.ToString() + $"Materijal: {materijal}. Eksponat: SKULPTURA.";
        }

        #endregion
    }
}
