﻿using System;

namespace EnumConsoleApp.Eksponati
{
    public class Eksponat
    {
        #region Attributes

        private string naziv;
        private string autor;
        private double cena;
        private DateTime datumPrijema;

        #endregion

        #region Get i Set methods

        public string Naziv
        {
            get { return naziv; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception("Naziv ne sme biti null ili prazan.");
                }
                else
                {
                    naziv = value;
                }
            }
        }

        public string Autor
        {
            get { return autor; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception("Autor ne sme biti null ili prazan.");
                }
                else
                {
                    autor = value;
                }
            }
        }


        public double Cena
        {
            get { return cena; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("Cena mora biti veca od nule.");
                }
                else
                {
                    cena = value;
                }
            }
        }

        public DateTime DatumPrijema
        {
            get { return datumPrijema; }
            set
            {
                if (value == null && value > DateTime.Now)
                {
                    throw new Exception("Datum ne sme biti null ili posle trenutnog datuma.");
                }
                else
                {
                    datumPrijema = value;
                }
            }
        }

        #endregion

        #region Overrides of Object

        public override string ToString()
        {
            return $"Eksponat - Naziv: {naziv}, Autor: {autor}, Cena: {cena}, Datum prijema: {datumPrijema}";
        }

        #endregion
    }
}
