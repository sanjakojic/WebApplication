﻿
namespace EnumConsoleApp.Eksponati.Slike
{
    public class Slika : Eksponat
    {
        #region ToString method
        public override string ToString()
        {
            return base.ToString() + "Eksponat: SLIKA.";
        }

        #endregion
    }
}
