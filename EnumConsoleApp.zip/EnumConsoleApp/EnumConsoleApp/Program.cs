﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnumConsoleApp.Eksponati;
using EnumConsoleApp.Eksponati.Skulpture;
using EnumConsoleApp.Eksponati.Slike;

namespace EnumConsoleApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            DateTime datum = new DateTime(2017, 01, 01);
            string datumString = datum.ToString("dd.MM.yyyy");

            Skulptura skulptura = new Skulptura();
            skulptura.Materijal = "bronza";
            skulptura.Autor = "Mikelandjelo";
            skulptura.Naziv = "David";
            skulptura.Cena = 11000;
            skulptura.DatumPrijema = new DateTime(2017,07,14);

            Skulptura skulptura2 = new Skulptura();
            skulptura2.Materijal = "bronza";
            skulptura2.Autor = "Roden";
            skulptura2.Naziv = "Mislilac";
            skulptura2.Cena = 1500;
            skulptura2.DatumPrijema = new DateTime(2017, 05, 14);

            Slika slika = new Slika();
            slika.Naziv = "Suncokreti";
            slika.Autor = "Vinsent Van Gog";
            slika.DatumPrijema = new DateTime(2018,05,11);
            slika.Cena = 55000;

            Galerija.Galerija galerija = new Galerija.Galerija();
            galerija.UnesiEksponat(skulptura);
            galerija.UnesiEksponat(slika);
            galerija.UnesiEksponat(skulptura2);

            galerija.UvediPopust(5);

            Eksponat[] eksponati = new Eksponat[2];
            eksponati = galerija.VratiNajskupljeEksponate();

            

            Console.ReadLine();
        }
    }
}
