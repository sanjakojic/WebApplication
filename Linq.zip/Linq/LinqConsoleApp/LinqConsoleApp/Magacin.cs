﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqConsoleApp
{
    public class Magacin
    {
        private List<Proizvod> proizvodi;

        public Magacin()
        {
            proizvodi = new List<Proizvod>();
        }


        public void UcitajIzFajlaIvana()
        {
            string path = @"C:\Users\sanja.kojic\Desktop\Proizvodi.txt";

            using (StreamReader sr = File.OpenText(path))
            {
                string s = "";
                bool prviRed = true;

                while ((s = sr.ReadLine()) != null)
                {
                    if (prviRed)
                    {
                        prviRed = false;
                    }
                    else
                    {
                        string[] nizReci = s.Split(' ');
                        Proizvod p = new Proizvod();
                        p.Sifra = int.Parse(nizReci[0]);
                        p.Naziv = nizReci[1];
                        p.Kolicina = int.Parse(nizReci[2]);

                        if (!proizvodi.Contains(p))
                        {
                            proizvodi.Add(p);
                        }
                    }
                }
            }
        }


        public void UcitajIzFajlaRadisa()
        {
            string path = @"C:\Users\sanja.kojic\Desktop\Proizvodi.txt";

            using (StreamReader sr = File.OpenText(path))
            {
                string linija = sr.ReadLine();
                string[] nizPodaci = null;

                while (linija != null)
                {
                    linija = sr.ReadLine();
                    nizPodaci = linija.Split(' ');
                    Proizvod p = new Proizvod()
                    {
                        Sifra = int.Parse(nizPodaci[0]),
                        Naziv =  nizPodaci[1],
                        Kolicina = int.Parse(nizPodaci[2])
                    };

                    if (proizvodi.Contains(p))
                    {
                        throw new Exception("Proizvod vec postoji u listi.");
                    }
                    else
                    {
                        proizvodi.Add(p);
                    }
                }

            }

            
        }


        public void SastaviListuNabavkeKatarina()
        {
            string path = @"C:\Users\sanja.kojic\Desktop\Nabavka.txt";

            using (StreamWriter sw = new StreamWriter(path))
            {
                sw.WriteLine("Proizvodi koje je potrebno nabaviti: ");
                int rbr = 1;
                foreach (var item in proizvodi)
                {
                    if (item.Kolicina < 5)
                    {
                        sw.WriteLine($"{rbr} {item.Sifra} {item.Naziv} {item.Kolicina}");
                        rbr++;
                    }
                }
                sw.Close();
            }
        }


        public void DopunaProizvodaSnezana()
        {
            List<Proizvod> listaDopune = new List<Proizvod>();
            string path = @"C:\Users\sanja.kojic\Desktop\Dopuna.txt";

            using (StreamReader sr = File.OpenText(path))
            {
                string linija = String.Empty;
                while ((linija = sr.ReadLine()) != null)
                {
                    string[] nizReci = linija.Split(' ');
                    Proizvod p = new Proizvod();
                    p.Sifra = int.Parse(nizReci[0]);
                    p.Naziv = nizReci[1];
                    p.Kolicina = int.Parse(nizReci[2]);

                    if (!listaDopune.Contains(p))
                    {
                        listaDopune.Add(p);
                    }
                }
            }

            foreach (var dopuna in listaDopune)
            {
                foreach (var proizvod in proizvodi)
                {
                    if (proizvod.Sifra == dopuna.Sifra)
                    {
                        proizvod.Kolicina = proizvod.Kolicina + dopuna.Kolicina;
                    }
                    else
                    {
                        proizvodi.Add(dopuna);
                    }
                }
                
            }

            

        }


        public void Ispisi()
        {
            foreach (var item in proizvodi)
            {
                Console.WriteLine(item);
            }
        }


    }
}
