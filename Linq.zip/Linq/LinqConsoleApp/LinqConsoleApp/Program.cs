﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqConsoleApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Magacin magacin = new Magacin();
            //magacin.UcitajIzFajlaIvana();

            //magacin.SastaviListuNabavkeKatarina();

            //magacin.DopunaProizvodaSnezana();

            //magacin.Ispisi();

            //int[] nizBrojeva = new[]
            //{
            //    0,
            //    1,
            //    2,
            //    3,
            //    4,
            //    5,
            //    6,
            //    7,
            //    8,
            //    9
            //};

            //IEnumerable<int> query = from broj in nizBrojeva
            //            where (broj % 2) == 0
            //            select broj;

            //foreach (var item in query)
            //{
            //    Console.WriteLine(item);
            //}

            //int[] niz = new[]
            //{
            //    1,
            //    3,
            //    -2,
            //    -4,
            //    -7,
            //    -3,
            //    -8,
            //    12,
            //    19,
            //    6,
            //    9,
            //    10,
            //    14
            //};

            //IEnumerable<int> query = from broj in niz
            //                         where broj > 0 && broj < 12
            //                         select broj;

            //foreach (var item in query)
            //{
            //    Console.WriteLine(item);
            //}


            int[] niz = new[]
            {
                3,
                9,
                2,
                8,
                6,
                5
            };

            var query = from broj in niz
                        let kvadrat = broj * broj
                        where kvadrat > 20
                        select new
                        {
                            broj,
                            kvadrat

                        };

            foreach (var item in query)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();
        }
    }
}
