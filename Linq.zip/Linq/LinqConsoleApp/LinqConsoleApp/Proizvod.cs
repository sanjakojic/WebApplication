﻿using System;

namespace LinqConsoleApp
{
    public class Proizvod
    {
        private int sifra;
        private string naziv;
        private int kolicina;

        public int Sifra
        {
            get { return sifra; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("Sifra mora biti veca ili jedna 0.");
                }
                else
                {
                    sifra = value;
                }
            }
        }

        public int Kolicina
        {
            get { return kolicina; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("Kolicina mora biti veca ili jedna 0.");
                }
                else
                {
                    kolicina = value;
                }
            }
        }


        public string Naziv
        {

            get { return naziv; }
            set
            {
                if (value == null)
                {
                    throw new Exception("Naziv ne sme biti null.");
                }
                else
                {
                    naziv = value;
                }
            }
        }

        #region Overrides of Object

        /// <inheritdoc />
        public override string ToString()
        {
            return sifra + " " + naziv + " " + kolicina;
        }

        #endregion

        #region Equals Radisa
        public override bool Equals(object obj)
        {
            Proizvod p = obj as Proizvod;
            if (sifra == p.Sifra && kolicina == p.Kolicina && naziv.Equals(p.Naziv))
            {
                return true;
            }
            return false;
        }
        #endregion
    }
}
