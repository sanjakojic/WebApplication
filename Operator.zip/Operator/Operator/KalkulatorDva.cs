﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator
{
    public class KalkulatorDva
    {
        public int Saberi(int broj1, int broj2)
        {
            int rezultat = broj1 + broj2;

            return rezultat;
        }

        public double Saberi(double broj1, double broj2)
        {
            double rezultat = broj1 + broj2;

            return rezultat;
        }
    }
}
