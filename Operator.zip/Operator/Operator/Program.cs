﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            //Kalkulator k = new Kalkulator();

            //Osoba o = new Osoba();
            //o.Ime = "Sanja";
            //o.UnesiIme("Pera");

            //Console.WriteLine(o.Ime);

            //ZamenaBrojeva zamenaBr = new ZamenaBrojeva();

            //int x = 10;
            //int y = 12;

            //Console.WriteLine("Vrednost x je: " + x);
            //Console.WriteLine("Vrednost y je: " + y);

            //zamenaBr.ZameniMesta(x,y);

            //Console.WriteLine("Vrednost x posle zamene je: " + x);
            //Console.WriteLine("Vrednost y posle zamene je: " + y);

            //Brojevi broj = new Brojevi();
            //broj.A = 5;
            //broj.B = 7;

            //Console.WriteLine("Vrednost A je: " + broj.A);
            //Console.WriteLine("Vrednost B je: " + broj.B);

            //zamenaBr.ZameniMesta(broj);

            //Console.WriteLine("Vrednost A posle zamene je: " + broj.A);
            //Console.WriteLine("Vrednost B posle zamene je: " + broj.B);

            //KalkulatorDva kalkulator = new KalkulatorDva();

            //int brojA = 10;
            //int brojB = 5;
            //int rezultatInt = kalkulator.Saberi(brojA, brojB);
            //Console.WriteLine(rezultatInt);

            //double brojX = 12.55;
            //double brojY = 10.23;
            //double rezultatDouble = kalkulator.Saberi(brojX, brojY);
            //Console.WriteLine(rezultatDouble);

            //Radio radio1 = new Radio();
            //Radio radio2 = new Radio();
            //Radio radio3 = new Radio();
            
            //radio1.PodesiAmFrekvenciju(570);
            //radio1.PromeniBandNaAm();
            //radio1.IspisiParametre();
            
            //Console.WriteLine("-------------------");

            //radio2.PodesiFmFrekvenciju(87.9);
            //radio2.IspisiParametre();

            //Console.WriteLine("-------------------");

            //radio3.PodesiFmFrekvenciju(107.9);
            //radio3.IspisiParametre();
            //radio3.PodesiFmFrekvenciju(89.9);
            //int rezultatAm = radio3.VratiAmFrekvenciju();
            //Console.WriteLine(rezultatAm);
            //radio3.IspisiParametre();

            //KlimaUredjaj klima1 = new KlimaUredjaj();
            //KlimaUredjaj klima2 = new KlimaUredjaj();

            //klima1.UkljuciRezimGrejanja();
            //klima1.PodesiTemperaturu(27);

            //klima2.UkljuciRezimHladjenja();
            //klima2.PodesiTemperaturu(20);

            //klima1.IspisiParametre();
            //klima2.IspisiParametre();
          
            KonvertorValute konvertor = new KonvertorValute();

            konvertor.PostaviKursDolara(60.34);
            konvertor.PostaviKursEvra(76.89);

            double iznosUSD = konvertor.KonvertujeDolareUDinare(60);
            Console.WriteLine(iznosUSD);

            double iznosEUR = konvertor.KonvertujEvreUDinare(45);
            Console.WriteLine(iznosEUR);

            double iznosDinUsd = konvertor.KonvertujDinareUDolare(6034);
            Console.WriteLine(iznosDinUsd);

            double iznosDinEur = konvertor.KonvertujDinareUEvre(150);
            Console.WriteLine(iznosDinEur);

            Console.ReadLine();

        }
    }
}
