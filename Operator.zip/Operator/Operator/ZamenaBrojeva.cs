﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator
{
    public class ZamenaBrojeva
    {
        public void ZameniMesta(int a, int b)
        {
            int pomocna;
            pomocna = a;
            a = b;
            b = pomocna;
        }

        public void ZameniMesta(Brojevi br)
        {
            int pomocna;
            pomocna = br.A;
            br.A = br.B;
            br.B = pomocna;
        }

    }
}
