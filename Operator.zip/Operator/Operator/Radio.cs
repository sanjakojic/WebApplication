﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator
{
    public class Radio
    {
        public double FmFrekvencija = 87.5;
        public int AmFrekvencija = 567;
        public char Band = 'F';

        public void PodesiFmFrekvenciju(double FmFrekvencija)
        {
            this.FmFrekvencija = FmFrekvencija;
        }

        public void PodesiAmFrekvenciju(int AmFrekvencija)
        {
            this.AmFrekvencija = AmFrekvencija;
        }

        public double VratiFmFrekvenciju()
        {
            return FmFrekvencija;
        }

        public int VratiAmFrekvenciju()
        {
            return AmFrekvencija;
        }

        public void PromeniBandNaAm()
        {
            Band = 'A';
        }

        public void PromeniBandNaFm()
        {
            Band = 'F';
        }

        public char VratiBand()
        {
            return Band;
        }

        public void IspisiParametre()
        {
            Console.WriteLine("Vrednost FmFrekvencije: " + FmFrekvencija);
            Console.WriteLine("Vrednost AmFrekvencije: " + AmFrekvencija);
            Console.WriteLine("Vrednost Band-a: " + Band);
        }
    }
}
