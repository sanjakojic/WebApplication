﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator
{
    public class KlimaUredjaj
    {
        public int Temperatura = 18;
        public char RezimRada = 'A';

        public void SmanjiTemperaturu()
        {
            Temperatura = Temperatura - 1;
        }

        public void PovecajTemperaturu()
        {
            Temperatura = Temperatura + 1;
        }

        public void PodesiTemperaturu(int Temperatura)
        {
            this.Temperatura = Temperatura;
        }

        public void UkljuciRezimGrejanja()
        {
            RezimRada = 'G';
        }

        public void UkljuciRezimHladjenja()
        {
            RezimRada = 'H';
        }

        public void UkljuciRezimAutomatski()
        {
            RezimRada = 'A';
        }

        public void IspisiParametre()
        {
            Console.WriteLine("Temperatura je: " + Temperatura);
            Console.WriteLine("Rezim rada je: " + RezimRada);
        }
    }
}
