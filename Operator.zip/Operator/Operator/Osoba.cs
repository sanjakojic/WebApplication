﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator
{
    public class Osoba
    {
        public string Ime;

        public void UnesiIme(string ime)
        {
            this.Ime = ime;
        }
    }
}
