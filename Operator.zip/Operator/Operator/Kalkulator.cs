﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator
{
    public class Kalkulator
    {
        public double Pi = 3.14;

        public int Saberi(int a, int b)
        {
            int rezultat = 0;
            rezultat = a + b;
            return rezultat;
        }

        public double ObimKruga(double poluprecnik)
        {
            double rezultat = 0;
            rezultat = 2 * poluprecnik * Pi;
            return rezultat;
        }
    }
}
