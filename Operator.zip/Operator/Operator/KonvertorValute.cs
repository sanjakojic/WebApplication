﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator
{
    public class KonvertorValute
    {
        public double KursEvra;
        public double KursDolara;

        public void PostaviKursEvra(double KursEvra)
        {
            this.KursEvra = KursEvra;
        }

        public void PostaviKursDolara(double KursDolara)
        {
            this.KursDolara = KursDolara;
        }

        public double KonvertujDinareUEvre(double DinarskiIznos)
        {
            double iznos = 0;
            iznos = DinarskiIznos / KursEvra;
            return iznos;
        }

        public double KonvertujDinareUDolare(double DinarskiIznos)
        {
            double iznos = 0;
            iznos = DinarskiIznos / KursDolara;
            return iznos;
        }

        public double KonvertujEvreUDinare(double EvroIznos)
        {
            double iznos = 0;
            iznos = EvroIznos * KursEvra;
            return iznos;
        }

        public double KonvertujeDolareUDinare(double DolarIznos)
        {
            double iznos = 0;
            iznos = DolarIznos * KursDolara;
            return iznos;
        }

        public void Ispisi()
        {
            Console.WriteLine("Kurs Evra: " + KursEvra);
            Console.WriteLine("Kurs Dolara: " + KursDolara);
        }
    }
}
