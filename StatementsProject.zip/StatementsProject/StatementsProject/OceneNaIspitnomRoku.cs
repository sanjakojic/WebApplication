﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementsProject
{
    public class OceneNaIspitnomRoku
    {
        public int[] Ocene = new int[100]; //0-99
        public int brojac = 0;

        public void UnesiOcenu(int ocena)
        {
            Ocene[brojac] = ocena;
            brojac++;
        }

        public void Ispisi()
        {
            for (int i = 0; i < Ocene.Length; i++)
            {
                Console.WriteLine(Ocene[i]);
            }
        }
    }
}
