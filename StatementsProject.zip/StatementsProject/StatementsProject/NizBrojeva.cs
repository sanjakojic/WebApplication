﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementsProject
{
    public class NizBrojeva
    {
        public int[] Niz = new int[10]; // 0-9
        public int brojac = 0;

        public void DodajElement(int element)
        {
            Niz[brojac] = element;
            brojac++;
        }

        public void IspisiPrviElement()
        {
            Console.WriteLine(Niz[0]);
        }

        public void IspisiDesetiElement()
        {
            Console.WriteLine(Niz[9]);
        }

        public void IspisiElement(int indeks)
        {
            Console.WriteLine(Niz[indeks]);
        }

        public void Ispisi()
        {
            for (int i = 0; i < Niz.Length; i++)
            {
                Console.WriteLine(Niz[i]);   
            }
        }

        public int VratiZbir()
        {
            int zbir = 0;
            for (int i = 0; i < Niz.Length; i++)
            {
                zbir = zbir + Niz[i];
            }
            return zbir;
        }

        public int VratiProizvod()
        {
            int proizvod = 1;
            for (int i = 0; i < brojac; i++)
            {
                proizvod = proizvod * Niz[i];
            }
            return proizvod;
        }

        public int MinElement()
        {
            int min = Niz[0];
            for (int i = 0; i < brojac; i++)
            {
                if (Niz[i] < min)
                {
                    min = Niz[i];
                }
            }
            return min;
        }

        public int MaxElement()
        {
            int max = Niz[0];
            for (int i = 0; i < brojac; i++)
            {
                if (Niz[i] > max)
                {
                    max = Niz[i];
                }
            }
            return max;
        }

        public bool Provera(int broj)
        {
            for (int i = 0; i < brojac; i++)
            {
                if (Niz[i] == broj)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
