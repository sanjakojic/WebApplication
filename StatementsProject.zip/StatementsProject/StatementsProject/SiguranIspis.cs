﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementsProject
{
    public class SiguranIspis
    {
        public static void Ispisi(string poruka, int a)
        {
            int brojac = 0;
            do
            {
                Console.WriteLine(poruka);
                brojac++;
            } while (brojac<a);
        }
    }
}
