﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementsProject
{
    public class DesifrovanjeDNK
    {
        public static void DesifrujDNK(char karika)
        {
            switch (karika)
            {
                case 'A':
                    Console.WriteLine("Adenin");
                    break;
                case 'C':
                    Console.WriteLine("Citozin");
                    break;
                case 'G':
                    Console.WriteLine("Guanin");
                    break;
                case 'T':
                    Console.WriteLine("Timin");
                    break;
                default:
                   Console.WriteLine("Greska!");
                    break;
            }
        }
    }
}
