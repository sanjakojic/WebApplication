﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementsProject
{
    public class Program
    {
        static void Main(string[] args)
        {
            //DesifrovanjeDNK.DesifrujDNK('M');

            //Sifarnik.IspisiOcenu(4);
            //string ocena = Sifarnik.VratiOcenu(3);
            //Console.WriteLine(ocena);

            //Sifarnik.ZnakIliInterpunkcija('?');

            //SiguranIspis.Ispisi("Dobar dan", 5);
            //SiguranIspis.Ispisi("Laku noc", -5);

            //MesecniProfiti mp = new MesecniProfiti();
            //mp.UnesiProfite(122.33,2);
            //mp.UnesiProfite(455.45,5);
            //mp.UnesiProfite(789,7);
            //mp.Ispisi();

            //double februarProfit = mp.Profiti[1];
            //Console.WriteLine("Mesec februar: " + februarProfit);

            //OceneNaIspitnomRoku ocene = new OceneNaIspitnomRoku();
            //ocene.UnesiOcenu(5);
            //ocene.UnesiOcenu(10);
            //ocene.UnesiOcenu(10);
            //ocene.UnesiOcenu(7);
            //ocene.UnesiOcenu(8);

            //ocene.Ispisi();

            NizBrojeva broj1 = new NizBrojeva();
            NizBrojeva broj2 = new NizBrojeva();

            broj1.DodajElement(4);
            broj1.DodajElement(7);

            broj2.DodajElement(3);
            broj2.DodajElement(5);
            broj2.DodajElement(10);

            Console.WriteLine("Zbir prvog niza: " + broj1.VratiZbir());

            int min = broj2.Niz.Min();
            Console.WriteLine("Gotova metoda min: " + min + ", nasa metoda min: " + broj2.MinElement());

            Console.ReadLine();
        }
    }
}
