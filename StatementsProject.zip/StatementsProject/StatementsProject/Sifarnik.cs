﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementsProject
{
    public class Sifarnik
    {
        public static void IspisiOcenu(int ocena)
        {
            switch (ocena)
            {
                case 5:
                    Console.WriteLine("Odlican");
                    break;
                case 4:
                    Console.WriteLine("Vrlo dobar");
                    break;
                case 3:
                    Console.WriteLine("Dobar");
                    break;
                case 2:
                    Console.WriteLine("Dovoljan");
                    break;
                case 1:
                    Console.WriteLine("Nedovoljan");
                    break;
                default:
                    Console.WriteLine("Greska");
                    break;
            }
        }


        public static string VratiOcenu(int ocena)
        {
            switch (ocena)
            {
                case 5:
                    return "Odlican";
                case 4:
                    return "Vrlo dobar";
                case 3:
                    return "Dobar";
                case 2:
                    return "Dovoljan";
                case 1:
                    return "Nedovoljan";
                default:
                    return "Greska";
            }
        }


        public static void ZnakIliInterpunkcija(char karakter)
        {
            switch (karakter)
            {
                case '!':
                case '.':
                case ',':
                case '?':
                case ';':
                case ':':
                    Console.WriteLine("Znak interpunkcije");
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    Console.WriteLine("Cifra");
                    break;
            }
        }

    }
}
