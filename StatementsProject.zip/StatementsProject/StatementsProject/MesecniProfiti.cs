﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatementsProject
{
    public class MesecniProfiti
    {
        public double[] Profiti = new double[12]; //0-11

        public void UnesiProfite(double profit, int mesec)
        {
            Profiti[mesec-1] = profit;
        }

        public void Ispisi()
        {
            for (int i = 0; i < Profiti.Length; i++)
            {
                Console.WriteLine(Profiti[i]);
            }
        }
    }
}
