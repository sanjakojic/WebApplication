﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace LinqPracticeApp
{
    public class BaseClass
    {
        public static void BrojeviIUcestanostClassic()
        {
            int[] niz = new[]
            {
                5,
                9,
                1,
                2,
                3,
                7,
                5,
                6,
                7,
                3,
                7,
                6,
                8,
                5,
                4,
                9,
                6,
                2
            };


            var query = from broj in niz
                        group broj by broj
                        into grupaBrojeva
                        select grupaBrojeva;


            foreach (var item in query)
            {
                Console.WriteLine("Broj: " + item.Key + " pojavljuje se " + item.Count() + " puta.");
            }

        }


        public static void UcestanostKaraktera()
        {
            string str = String.Empty;

            Console.WriteLine("Unesite zeljenu rec:");
            str = Console.ReadLine();

            var query = from slovo in str
                        group slovo by slovo
                        into slova
                        select slova;

            foreach (var item in query)
            {
                Console.WriteLine("Slovo: " + item.Key + " se pojavljuje: " + item.Count() + " puta.");
            }
        }


        public static void DaniUNedelji()
        {
            string[] daniUNedelji =
            {
                "Ponedeljak",
                "Utorak",
                "Sreda",
                "Cetvrtak",
                "Petak",
                "Subota",
                "Nedelja"
            };

            //where clause ako zelimo da znamo koji dan pocinje sa P
            var query = from dan in daniUNedelji
                        where dan.StartsWith("P")
                        select dan;

            foreach (var item in query)
            {
                Console.WriteLine(item);
            }
        }


        public static void PronadjiGradove()
        {
            string[] gradovi =
            {
                "Rim",
                "Pariz",
                "London",
                "Lisabon",
                "Amsterdam",
                "Roterdam",
                "Beograd",
                "Bukurest"
            };

            Console.WriteLine("Unesi prvi karakter: ");
            char prvi = Console.ReadKey().KeyChar;
            string prviKarakter = $"{prvi.ToString().ToLower()}";

            Console.WriteLine();

            Console.WriteLine("Unesite poslednji karakter: ");
            string poslednji = Console.ReadLine();
            

            Console.WriteLine();

            var query = from grad in gradovi
                        where grad.ToLower().StartsWith(prviKarakter)
                              && grad.EndsWith(poslednji.ToLower())
                        select grad;

            foreach (var item in query)
            {
                Console.WriteLine(item);
            }

        }


        public static void BrojeviVeciOd80()
        {
            List<int> lista = new List<int>()
            {
                55, 120, 230, 12, 87, 95, 435, 81,45
            };


            var query = from br in lista
                        where br > 80
                        select br;

            List<int> query2 = lista.FindAll(x => x > 80);

            Console.WriteLine("Lista 1");

            foreach (var broj in query)
            {
                Console.WriteLine(broj);
            }

            Console.WriteLine("--------");

            Console.WriteLine("Lista 2");

            foreach (var broj in query2)
            {
                Console.WriteLine(broj);
            }
        }


        public static void BrojeviVeciOdN()
        {
            List<int> listaBrojeva = new List<int>();

            Console.WriteLine("Koliko elemenata treba da zadrzi lista?");
            string brojacStr = Console.ReadLine();
            int broj = int.Parse(brojacStr);

            for (int i = 0; i < broj; i++)
            {
                Console.WriteLine("Unesite broj:");
                string brojStr = Console.ReadLine();
                int unos = int.Parse(brojStr);
                listaBrojeva.Add(unos);
            }

            Console.WriteLine("Unesite vrednost iznad koje zelite filtriranje:");
            string uslovStr = Console.ReadLine();
            int uslov = int.Parse(uslovStr);

            var query = from br in listaBrojeva
                        where br > uslov
                        select br;

            Console.WriteLine("Filtrirana lista:");

            foreach (var item in query)
            {
                Console.WriteLine(item);
            }

        }


        public static void VratiImenaSaUslovom()
        {
            string[] imena =
            {
                "Perica", "Marko", "Zeljko", "Tanja", "Vanja", "Mikica", "Zikica"
            };

            var query = from s in imena
                        where s.Length == 5
                        orderby s
                        select s.ToUpper();

            foreach (var ime in query)
            {
                Console.WriteLine(ime);
            }

        }


        public static void IzbrisiSlovoO()
        {
            List<string> lista = new List<string>()
            {
                "a","e","i","o","u"
            };

            //kada imamo vise slova O
            //var query = from x in lista
            //            where !x.Equals("o")
            //            select x;

            //lista = query.ToList();

            //kada imamo jedno slovo O
            string slovo = lista.FirstOrDefault(x => x.Equals("o"));
            lista.Remove(slovo);

            foreach (var item in lista)
            {
                Console.WriteLine(item);
            }
        }


        public static void VratiKombinaciju()
        {
            char[] slova =
            {
                'X',
                'Y',
                'Z'
            };

            int[] brojevi =
            {
                1,2,3,4
            };

            var query = from s in slova
                        from br in brojevi
                        select new
                        {
                            s,
                            br
                        };

            foreach (var item in query)
            {
                Console.WriteLine(item);
            }

        }

    }
}
