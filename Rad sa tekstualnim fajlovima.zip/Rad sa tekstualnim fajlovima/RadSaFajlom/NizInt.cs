﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadSaFajlom
{
    public class NizInt
    {
        private int[] niz;
        private int brojac;

        public void PostaviKapacitet()
        {
            brojac = 0;
            Console.WriteLine("Unesite zeljeni kapacitet niza: ");

            try
            {
                string odgovor = Console.ReadLine();
                int kapacitet = int.Parse(odgovor);

                if (kapacitet <= 0)
                {
                    niz = new int[10];
                }
                else
                {
                    niz = new int[kapacitet];
                }
            }
            catch (Exception e)
            {
                niz = new int[10];
                Console.WriteLine(e);
            }
        }


        public void UcitajNiz()
        {
            try
            {
                int kapacitetNiza = niz.Length;

                while (brojac < kapacitetNiza)
                {
                    Console.WriteLine("Unesite broj niza: ");
                    string rezultat = Console.ReadLine();
                    int broj = int.Parse(rezultat);
                    niz[brojac] = broj;
                    brojac++;
                }
            }
            catch (NullReferenceException)
            {
                Console.WriteLine("Niz nije inicijalizovan.");
            }
            catch (FormatException)
            {
                Console.WriteLine("Element niza mora biti ceo broj.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void IspisiClanoveNiza()
        {
            try
            {
                int kapacitetNiza = niz.Length;
                for (int i = 0; i < niz.Length; i++)
                {
                    Console.Write(niz[i] + ", ");
                }
            }
            catch (NullReferenceException)
            {
                Console.WriteLine("Niz nije inicijalizovan.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


    }
}
