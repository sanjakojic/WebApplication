﻿using System;
using System.IO;


namespace RadSaFajlom
{
    public class Program
    {
        static void Main(string[] args)
        {
            //NizInt niz = new NizInt();
            //niz.PostaviKapacitet();
            //niz.UcitajNiz();
            //niz.IspisiClanoveNiza();
            //Console.ReadLine();

            
        }
    }
}
