﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadSaFajlom
{
    public class RadSaTekstom
    {
        public static void UcitajTekst()
        {
            try
            {
                string path = @"C:\Users\Student\Desktop\Tekst.txt";

                using (StreamReader sr = File.OpenText(path))
                {
                    string s = string.Empty;

                    while ((s = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(s);
                    }
                }
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void UcitajOdredjeniFile(string nazivFajla)
        {
            try
            {
                string pathBezNaziva = @"C:\Users\Student\Desktop\";
                string path = pathBezNaziva + nazivFajla + ".txt";

                using (StreamReader sr = File.OpenText(path))
                {
                    string s = string.Empty;

                    while ((s = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(s);
                    }
                }
                Console.ReadLine();
            }
            catch (ArgumentNullException)
            {
                Console.WriteLine("Naziv file-a mora biti razlicit od null.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public static void BrebrojReci(string nazivFajla)
        {
            try
            {
                string pathBezNaziva = @"C:\Users\Student\Desktop\";
                string path = pathBezNaziva + nazivFajla + ".txt";

                using (StreamReader sr = File.OpenText(path))
                {
                    string s = string.Empty;
                    int brojacReci = 0;
 
                    while ((s = sr.ReadLine()) != null)
                    {
                        brojacReci += s.Split(' ').Length;
                    }
                    Console.WriteLine(brojacReci);
                }
                Console.ReadLine();
            }
            catch (ArgumentNullException)
            {
                Console.WriteLine("Naziv file-a mora biti razlicit od null.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public static bool DaLiSeNalaziRec(string rec)
        {
            try
            {
                string path = @"C:\Users\Student\Desktop\Tekst.txt";

                using (StreamReader sr = File.OpenText(path))
                {
                    string ceoTekst = sr.ReadToEnd();
                    string tekstBezTackeIZareza = ceoTekst.Replace('.', ' ').Replace(',', ' ').ToLower();
                    if (tekstBezTackeIZareza.Contains(rec.ToLower()))
                    {
                        return true;
                    }
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }


        public static void PrebrojRecenice()
        {
            try
            {
                string path = @"C:\Users\Student\Desktop\Tekst.txt";

                using (StreamReader sr = File.OpenText(path))
                {
                    string s = sr.ReadToEnd();
                    string receniceSaTackom = s.Replace('!', '.').Replace('?', '.');
                    string[] nizRecenica = receniceSaTackom.Split('.');
                    int brojRecenica = nizRecenica.Length;

                    Console.WriteLine("Broje recenica: " + brojRecenica);
  
                }
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public static void UpisiReciDuzeOdPet(string tekst)
        {
            try
            {
                string path = @"C:\Users\Student\Desktop\Tekst.txt";

                using (StreamWriter sr = File.AppendText(path))
                {
                    string[] nizReci = tekst.Split(' ');
                    foreach (var rec in nizReci)
                    {
                        if (rec.Length > 5)
                        {
                            sr.WriteLine(rec);
                            sr.Close();
                        }
                    }
                }
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        public static void UpisiRecSaSlovomA(string tekst)
        {
            try
            {
                string path = @"C:\Users\Student\Desktop\Tekst.txt";

                using (StreamWriter sr = File.AppendText(path))
                {
                    string[] nizReci = tekst.Split(' ');
                    foreach (var rec in nizReci)
                    {
                        if (rec.StartsWith("A"))
                        {
                            sr.WriteLine(rec);
                            sr.Close();
                        }
                    }
                }
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

    }
}
