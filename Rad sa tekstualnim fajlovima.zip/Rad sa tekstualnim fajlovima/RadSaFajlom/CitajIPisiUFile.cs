﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadSaFajlom
{
    public class CitajIPisiUFile
    {
        public static void CitajIzFajla()
        {
            try
            {
                string path = @"C:\Users\Student\Desktop\File.txt";

                using (StreamReader sr = File.OpenText(path))
                {
                    string s = string.Empty;

                    while ((s = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(s);
                    }
                }
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void UpisiUFajla()
        {
            try
            {
                string path = @"C:\Users\Student\Desktop\File.txt";

                using (StreamWriter sr = File.AppendText(path))
                {
                    sr.WriteLine("Smrzavamo se jako je hladno.");
                    sr.Close();

                    Console.WriteLine(File.ReadAllText(path));
                }
                Console.ReadLine();

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
