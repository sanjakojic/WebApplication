﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InterfaceConsoleApp.Banka;
using InterfaceConsoleApp.Prevoz;
using InterfaceConsoleApp.TestGrupa2;

namespace InterfaceConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Vozilo vozilo1 = new Automobil();
            //Vozilo vozilo2 = new Avion();

            //vozilo1.SetMarka("Mercedes");
            //vozilo1.SetModel("E220");

            //vozilo2.SetMarka("Boing");
            //vozilo2.SetModel("747");

            //vozilo1.Ispisi();
            //Console.WriteLine();
            //vozilo2.Ispisi();

            //AutomatNovca obicanAutomat = new AutomatNovca();
            //NapredniAutomatNovca napredniAutomat = new NapredniAutomatNovca();

            //obicanAutomat.UloziNovac(3000);
            //napredniAutomat.PodigniNovac(9999);

            //obicanAutomat.Ispis();
            //napredniAutomat.Ispisi();

            ParkingMesto mesto1 = new ParkingMesto();
            mesto1.SetRegistarskiBroj("BG 123 IV");
            mesto1.SetSlobodno(false);

            ParkingMesto mesto2 = new ParkingMesto();
            mesto2.SetRegistarskiBroj("NS 234 LO");
            mesto2.SetSlobodno(false);

            Parking parking = new Parking();
            parking.UvediVozilo(mesto1.GetRegistarskiBroj());
            parking.UvediVozilo(mesto2.GetRegistarskiBroj());

            parking.Ispisi();

            ParkingMesto mesto3 = new ParkingMesto();
            mesto3.SetRegistarskiBroj("KG 751 MM");
            mesto3.SetSlobodno(false);

            bool result = parking.DaLiImaSlobodnihMesta(mesto3);
            if (result)
            {
                Console.WriteLine("Parking sadrzi vozilo.");
                parking.IzvediVozilo(mesto3.GetRegistarskiBroj());
            }
            else
            {
                Console.WriteLine("Parking ne sadrzi vozilo.");
            }

            parking.Ispisi();

            Console.ReadLine();
        }
    }
}
