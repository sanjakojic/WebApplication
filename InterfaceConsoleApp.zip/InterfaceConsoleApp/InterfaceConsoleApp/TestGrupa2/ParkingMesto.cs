﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceConsoleApp.TestGrupa2
{
    public class ParkingMesto
    {
        private bool Slobodno;
        private string RegistarskiBroj;

        public void SetSlobodno(bool Slobodno)
        {
            this.Slobodno = Slobodno;
        }

        public bool GetSlobodno()
        {
            return Slobodno;
        }

        public void SetRegistarskiBroj(string RegistarskiBroj)
        {
            this.RegistarskiBroj = RegistarskiBroj;
        }

        public string GetRegistarskiBroj()
        {
            return RegistarskiBroj;
        }


        public override string ToString()
        {
            return $"Registarski broj: {RegistarskiBroj}, slobodno: {Slobodno}";
        }
    }

}
