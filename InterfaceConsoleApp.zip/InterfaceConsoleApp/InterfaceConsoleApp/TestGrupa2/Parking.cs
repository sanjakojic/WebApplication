﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceConsoleApp.TestGrupa2
{
    public class Parking
    {
        private List<ParkingMesto> Mesta;

        public Parking()
        {
            Mesta = new List<ParkingMesto>();
        }

        public bool DaLiImaSlobodnihMesta(ParkingMesto mesto)
        {
            if (Mesta.Contains(mesto))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void UvediVozilo(string registarskiBroj)
        {
            ParkingMesto parking = new ParkingMesto();
            parking.SetSlobodno(false);
            parking.SetRegistarskiBroj(registarskiBroj);
            bool result = DaLiImaSlobodnihMesta(parking);
            if (result)
            {
                Console.WriteLine("Greska, vec parkiran");
            }
            else
            {
                Mesta.Add(parking);
            }
        }

        public void IzvediVozilo(string registarskiBroj)
        {
            foreach (var item in Mesta)
            {
                if (item.GetRegistarskiBroj().Equals(registarskiBroj))
                {
                    Mesta.Remove(item);
                }
                else
                {
                    Console.WriteLine("Greska, nema vozila.");
                }
            }
        }


        public void Ispisi()
        {
            foreach (var item in Mesta)
            {
                Console.WriteLine(item);
            }
        }

    }
}
