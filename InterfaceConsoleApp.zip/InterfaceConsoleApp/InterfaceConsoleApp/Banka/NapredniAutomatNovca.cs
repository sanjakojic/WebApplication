﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceConsoleApp.Banka
{
    public class NapredniAutomatNovca : IAutomatNovca
    {
        private double Stanje = 20000.0;

        public void PodigniNovac(double iznos)
        {
            if (iznos > 0 && iznos < 10000 && iznos < Stanje)
            {
                Stanje -= iznos;
            }
            else
            {
                Console.WriteLine("Greska maksimalna isplata je 10.000 dinara");
            }
        }

        public void UloziNovac(double iznos)
        {
            if (iznos > 0 && iznos <= 20000)
            {
                Stanje += iznos;
            }
            if (iznos > 20000)
            {
                Console.WriteLine("Maksimalni iznos za uplatu je 20.000");
            }
            if (iznos < 0)
            {
                Console.WriteLine("Pa greska");
            }
        }

        public void Ispisi()
        {
            Console.WriteLine($"Trenutno stane je: {Stanje},a Maksimalno se moze uloziti 20.000 i podici 10.000");
        }
    }
}
