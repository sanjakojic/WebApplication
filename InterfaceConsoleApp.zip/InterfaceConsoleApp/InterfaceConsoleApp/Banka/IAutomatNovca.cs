﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceConsoleApp.Banka
{
    public interface IAutomatNovca
    {
        void UloziNovac(double iznos);

        void PodigniNovac(double iznos);
    }
}
