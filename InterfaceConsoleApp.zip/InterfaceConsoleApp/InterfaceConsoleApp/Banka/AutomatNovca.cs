﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceConsoleApp.Banka
{
    public class AutomatNovca : IAutomatNovca
    {
        private double Stanje = 5000.0;

        public void PodigniNovac(double iznos)
        {
            if (iznos > 0 && Stanje > iznos)
            {
                Stanje -= iznos;
                //ekvivalentno: Stanje = Stanje - iznos;
            }
            else
            {
                Console.WriteLine("Greska, nema dovoljno novca u automatu.");
            }
        }

        public void UloziNovac(double iznos)
        {
            if (iznos > 0)
            {
                Stanje += iznos;
                //ekvivalentno: Stanje = Stanje + iznos;
            }
            else
            {
                Console.WriteLine("Greska, iznos mora biti veci od nule.");
            }
        }

        public void Ispis()
        {
            Console.WriteLine($"Stanje u automatu: {Stanje}");
        }
    }
}
