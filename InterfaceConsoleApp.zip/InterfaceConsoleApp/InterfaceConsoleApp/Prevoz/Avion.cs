﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceConsoleApp.Prevoz
{
    public class Avion : Vozilo
    {
        public override bool DaLiIdePoKopnu()
        {
            return false;
        }

        public override bool DaLiIdePoVazduhu()
        {
            return true;
        }

        public override bool DaLiIdePoVodi()
        {
            return false;
        }

        public override void Ispisi()
        {
            base.Ispisi();
            Console.WriteLine("Vazdusno vozilo");
        }
    }
}
