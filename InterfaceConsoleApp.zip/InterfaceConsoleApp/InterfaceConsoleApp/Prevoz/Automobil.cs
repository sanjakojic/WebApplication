﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceConsoleApp.Prevoz
{
    public class Automobil : Vozilo
    {
        public override bool DaLiIdePoKopnu()
        {
            return true;
        }

        public override bool DaLiIdePoVazduhu()
        {
            return false;
        }

        public override bool DaLiIdePoVodi()
        {
            return false;
        }

        #region Overrides of Vozilo

        /// <inheritdoc />
        public override void Ispisi()
        {
            base.Ispisi();
            Console.WriteLine("Kopneno vozilo");
        }

        #endregion
    }
}
