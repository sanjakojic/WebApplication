﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceConsoleApp.Prevoz
{
    public abstract class Vozilo
    {
        private string Model;
        private string Marka;
        private string Specifikacija;
        public void SetMarka(string Marka)
        {
            if (Marka == null)
            {
                Console.WriteLine("Greska!");
            }

            else
            {
                this.Marka = Marka;
            }
        }

        public string GetMarka()
        {
            return this.Marka;
        }

        public void SetModel(string Model)
        {
            if (Model == null)
            {
                Console.WriteLine("Model ne moze biti null");
            }

            else
            {
                this.Model = Model;
            }
        }

        public string GetModel()
        {
            return this.Model;
        }

        public abstract bool DaLiIdePoKopnu();
        public abstract bool DaLiIdePoVodi();

        public abstract bool DaLiIdePoVazduhu();

        public virtual void Ispisi()
        {
            Console.WriteLine($"Marka: {Marka}, Model: {Model} ");
        }


    }
}

