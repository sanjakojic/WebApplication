﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleAppForPractice.zadatak1;

namespace ConsoleAppForPractice
{
    public class Program
    {
        static void Main(string[] args)
        {
            PotrosackaKorpa korpa = new PotrosackaKorpa(25);

            Namirnica namirnica1 = new Namirnica();
            namirnica1.Naziv = "Hleb";
            namirnica1.Cena = 50;

            Namirnica namirnica2 = new Namirnica();
            namirnica2.Naziv = "Mleko";
            namirnica2.Cena = 80;

            Namirnica namirnica3 = new Namirnica();
            namirnica3.Naziv = "Sok";
            namirnica3.Cena = 100;

            Namirnica namirnica4 = new Namirnica();
            namirnica4.Naziv = "Cokolada";
            namirnica4.Cena = 100;

            korpa.DodajUKorpu(namirnica1);
            korpa.DodajUKorpu(namirnica2);
            korpa.DodajUKorpu(namirnica3);
            korpa.DodajUKorpu(namirnica4);

            int ukupnaCena = korpa.IzracunajUkupnuCenu();
            Console.WriteLine("Ukupna cena: " + ukupnaCena);

            string najskuplja = korpa.NajskupljaNamirnica();
            Console.WriteLine("Najskuplja namirnica: " + najskuplja);

            Console.ReadLine();
        }
    }
}
