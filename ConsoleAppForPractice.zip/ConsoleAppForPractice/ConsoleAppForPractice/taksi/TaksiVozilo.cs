﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppForPractice.taksi
{
    public class TaksiVozilo
    {
        private string id;
        private int brojPoziva;
        private bool slobodan;

        public string Id
        {
            get { return id; }
            set
            {
                if (value == null && (value.Length < 10 || value.Length > 30))
                {
                    throw new Exception("Greska, id nije u rasponu.");
                }

                id = value;
            }
        }


        public int BrojPoziva
        {
            get { return brojPoziva; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("Broj poziva mora biti veci od nula.");
                }

                brojPoziva = value;
            }
        }


        public bool Slobodan
        {
            get { return slobodan; }
            set { slobodan = value; }
        }

        #region Overrides of Object

        /// <inheritdoc />
        public override string ToString()
        {
            return $"Id: {id}, Broj poziva: {brojPoziva}, Slobodan: {slobodan}";
        }

        #endregion
    }
}
