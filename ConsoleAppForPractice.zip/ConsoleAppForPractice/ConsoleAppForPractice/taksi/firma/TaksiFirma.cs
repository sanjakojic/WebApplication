﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppForPractice.taksi.firma
{
    public class TaksiFirma
    {
        private TaksiVozilo[] vozila;
        private int brojac;

        public TaksiFirma()
        {
            vozila = new TaksiVozilo[1000];
            brojac = 0;
        }

        public void UnesiTaksi(TaksiVozilo taxi)
        {
            if ( brojac < vozila.Length && vozila[brojac] == null)
            {
                taxi.BrojPoziva = 0;
                vozila[brojac] = taxi;
                //drugi nacin
                //vozila[brojac].BrojPoziva = 0;
                brojac++;
            }
            else
            {
                Console.WriteLine("Nema mesta!");
            }
        }
    }
}
