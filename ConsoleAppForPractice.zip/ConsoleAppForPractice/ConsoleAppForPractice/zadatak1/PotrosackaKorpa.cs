﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppForPractice.zadatak1
{
    public class PotrosackaKorpa
    {
        private Namirnica[] namirnice;
        private int brojac;

        public PotrosackaKorpa(int kapacitetKorpe)
        {
            brojac = 0;

            if (kapacitetKorpe > 0 && kapacitetKorpe < 20)
            {
                namirnice = new Namirnica[kapacitetKorpe];
            }
            else
            {
                namirnice = new Namirnica[10];
                Console.WriteLine("Greska");
            }
        }

        public void DodajUKorpu(Namirnica namirnica)
        {
            if (brojac < namirnice.Length)
            {
                namirnice[brojac] = namirnica;
                brojac++;
            }
            else
            {
                throw new IndexOutOfRangeException("Nema mesta.");
            }
        }

        public int IzracunajUkupnuCenu()
        {
            int ukupnaCena = 0;
            for (int i = 0; i < brojac; i++)
            {
                ukupnaCena += namirnice[i].Cena;
            }
            return ukupnaCena;
        }


        public string NajskupljaNamirnica()
        {
            if (brojac == 0)
            {
                return null;
            }

            Namirnica najskuplja = namirnice[0];
            for (int i = 0; i < namirnice.Length; i++)
            {
                if (namirnice[i] != null && namirnice[i].Cena > najskuplja.Cena)
                {
                    najskuplja = namirnice[i];
                }
            }

            return najskuplja.Naziv;
        }


    }
}
