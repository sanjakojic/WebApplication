﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppForPractice.zadatak1
{
    public class Namirnica
    {
        private string naziv;
        private int cena;

        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }

        public int Cena
        {
            get { return cena; }
            set { cena = value; }
        }

    }
}
