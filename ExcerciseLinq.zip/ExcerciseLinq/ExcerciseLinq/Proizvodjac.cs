﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcerciseLinq
{
    public class Proizvodjac
    {
        private int proizvodjacId;
        private string naziv;
        
        public int ProizvodjacId
        {
            get { return proizvodjacId; }
            set { proizvodjacId = value; }
        }

        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }


        public List<Proizvodjac> VratiProizvodjace()
        {
            List<Proizvodjac> lista = new List<Proizvodjac>();

            lista.Add(new Proizvodjac()
            {
                ProizvodjacId = 1111,
                Naziv = "Pionir"
            });

            lista.Add(new Proizvodjac()
            {
                ProizvodjacId = 2222,
                Naziv = "Imlek"
            });

            lista.Add(new Proizvodjac()
            {
                ProizvodjacId = 3333,
                Naziv = "Next"
            });

            lista.Add(new Proizvodjac()
            {
                ProizvodjacId = 4444,
                Naziv = "Rosa"
            });

            lista.Add(new Proizvodjac()
            {
                ProizvodjacId = 5555,
                Naziv = "Zajecarsko"
            });

            return lista;
        }


    }
}
