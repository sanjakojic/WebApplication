﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcerciseLinq
{
    public class Student
    {
        private int id;
        private string ime;
        private int poeni;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }

        public int Poeni
        {
            get { return poeni; }
            set { poeni = value; }
        }

        #region Overrides of Object

        /// <inheritdoc />
        public override string ToString()
        {
            return $"NamirnicaId: {id}, ime: {ime}, poeni: {poeni}";
        }

        #endregion



        public List<Student> ListaStudenata()
        {
            List<Student> lista = new List<Student>();

            Student st1 = new Student()
            {
                Id = 101,
                Ime = "Zeljko",
                Poeni = 845
            };

            lista.Add(st1);

            lista.Add(new Student()
            {
                Id = 102,
                Ime = "Vanja",
                Poeni = 417
            });

            lista.Add(new Student()
            {
                Id = 103,
                Ime = "Marija",
                Poeni = 754
            });

            lista.Add(new Student()
            {
                Id = 104,
                Ime = "Petar",
                Poeni = 901
            });

            lista.Add(new Student()
            {
                Id = 105,
                Ime = "Jovana",
                Poeni = 350
            });

            lista.Add(new Student()
            {
                Id = 106,
                Ime = "Natasa",
                Poeni = 623
            });

            lista.Add(new Student()
            {
                Id = 107,
                Ime = "Milan",
                Poeni = 594
            });


            return lista;
        }

    }
}
