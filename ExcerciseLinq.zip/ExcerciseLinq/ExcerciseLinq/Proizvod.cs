﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcerciseLinq
{
    public class Proizvod
    {
        private int id;
        private string naziv;
        private int cena;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }

        public int Cena
        {
            get { return cena; }
            set { cena = value; }
        }

        #region Overrides of Object

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{naziv} {cena}";
        }


        public List<Proizvod> VratiProizvode()
        {
            List<Proizvod> lista = new List<Proizvod>();

            lista.Add(new Proizvod()
            {
                Id = 1,
                Naziv = "Baterija",
                Cena = 250
            });

            lista.Add(new Proizvod()
            {
                Id = 2,
                Naziv = "Casa",
                Cena = 500
            });

            lista.Add(new Proizvod()
            {
                Id = 3,
                Naziv = "Stolica",
                Cena = 2500
            });


            return lista;
        }

        #endregion
    }
}
