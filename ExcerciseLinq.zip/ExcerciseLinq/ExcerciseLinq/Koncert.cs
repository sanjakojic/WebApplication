﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcerciseLinq
{
    public class Koncert
    {
        private int koncertId;
        private int pevacId;
        private int brojKoncerata;
        private int godina;

        public int KoncertId
        {
            get { return koncertId; }
            set { koncertId = value; }
        }

        public int PevacId
        {
            get { return pevacId; }
            set { pevacId = value; }
        }

        public int BrojKoncerata
        {
            get { return brojKoncerata; }
            set { brojKoncerata = value; }
        }

        public int Godina
        {
            get { return godina; }
            set { godina = value; }
        }

        public List<Koncert> VratiKoncerte()
        {
            List<Koncert> lista = new List<Koncert>();

            lista.Add(new Koncert()
            {
                KoncertId = 111,
                PevacId = 1,
                BrojKoncerata = 2,
                Godina = 2014
            });

            lista.Add(new Koncert()
            {
                KoncertId = 222,
                PevacId = 2,
                BrojKoncerata = 250,
                Godina = 2018
            });

            return lista;
        }
    }
}
