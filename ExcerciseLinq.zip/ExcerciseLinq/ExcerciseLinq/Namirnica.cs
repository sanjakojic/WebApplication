﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcerciseLinq
{
    public class Namirnica
    {
        private int namirnicaId;
        private int proizvodjacId;
        private string artikal;

        public int NamirnicaId
        {
            get { return namirnicaId; }
            set { namirnicaId = value; }
        }

        public int ProizvodjacId
        {
            get { return proizvodjacId; }
            set { proizvodjacId = value; }
        }

        public string Artikal
        {
            get { return artikal; }
            set { artikal = value; }
        }


        public List<Namirnica> VratiNamirnice()
        {
            List<Namirnica> listaNamirnica = new List<Namirnica>();

            listaNamirnica.Add(new Namirnica()
            {
                NamirnicaId = 1,
                ProizvodjacId = 1111,
                Artikal = "Cokolada"
            });

            listaNamirnica.Add(new Namirnica()
            {
                NamirnicaId = 2,
                ProizvodjacId = 2222,
                Artikal = "Mleko"
            });


            listaNamirnica.Add(new Namirnica()
            {
                NamirnicaId = 3,
                ProizvodjacId = 3333,
                Artikal = "Sok"
            });


            listaNamirnica.Add(new Namirnica()
            {
                NamirnicaId = 4,
                ProizvodjacId = 4444,
                Artikal = "Voda"
            });


            listaNamirnica.Add(new Namirnica()
            {
                NamirnicaId = 5,
                ProizvodjacId = 5555,
                Artikal = "Pivo"
            });


            return listaNamirnica;
        }
    }
}
