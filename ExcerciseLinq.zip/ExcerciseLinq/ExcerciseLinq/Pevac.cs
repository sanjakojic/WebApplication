﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcerciseLinq
{
    public class Pevac
    {
        private int pevacId;
        private string ime;
        private string prezime;

        public int PevacId
        {
            get { return pevacId; }
            set { pevacId = value; }
        }

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }

        public string Prezime
        {
            get { return prezime; }
            set { prezime = value; }
        }

        public List<Pevac> VratiPevace()
        {
            List<Pevac> lista = new List<Pevac>();

            lista.Add(new Pevac()
            {
                PevacId = 1,
                Ime = "Mitar",
                Prezime = "Miric"
            });

            lista.Add(new Pevac()
            {
                PevacId = 2,
                Ime = "Sejo",
                Prezime = "Kalac"
            });

            return lista;
        }
    }
}
