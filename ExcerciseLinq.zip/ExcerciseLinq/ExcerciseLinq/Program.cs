﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcerciseLinq
{
    public class Program
    {
        static void Main(string[] args)
        {
            #region Zadatak student

            Student student = new Student();
            List<Student> lista = student.ListaStudenata();

            foreach (var item in lista)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("----------------------");

            var query1 = from x in lista
                         where x.Ime.StartsWith("M")
                         select x;

            var query1Lam = lista.Where(x => x.Ime.StartsWith("M"));

            foreach (var item in query1Lam)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("----------------------");

            var query2 = from x in lista
                         where x.Ime.Contains("o")
                         select x;

            var query2Lam = lista.Where(x => x.Ime.Contains("o"));

            foreach (var item in query2Lam)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("----------------------");

            var query3 = from x in lista
                         orderby x.Id descending
                         select x;

            var query3Lam = lista.OrderByDescending(x => x.Id);

            foreach (var item in query3Lam)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("----------------------");

            var query4 = from x in lista
                         where x.Poeni > 550
                         orderby x.Poeni descending
                         select x;

            var query4Lam = lista.Where(x => x.Poeni > 550).OrderByDescending(x => x.Poeni);

            foreach (var item in query4Lam)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("----------------------");

            var query5 = from x in lista
                         where (x.Ime.Length > 5 && x.Poeni >= 600
                                && x.Poeni <= 729)
                         select new
                         {
                             x.Ime,
                             x.Poeni
                         };

            var query5Lam = lista.Where(x => x.Ime.Length > 5 && x.Poeni >= 600 && x.Poeni <= 729).Select(x => new {x.Ime, x.Poeni});

            foreach (var item in query5Lam)
            {
                Console.WriteLine(item);
            }

            #endregion


            #region Zadatak Kupovina

            Namirnica namirnica = new Namirnica();
            List<Namirnica> listaNamirnica = namirnica.VratiNamirnice();

            Kupovina kupovina = new Kupovina();
            List<Kupovina> listaKupovine = kupovina.VratiSveKupovine();

            var query = from nam in listaNamirnica
                        join k in listaKupovine on nam.NamirnicaId equals k.NamirnicaId
                        select new
                        {
                            nam.Artikal,
                            k.Kolicina
                        };           

            Console.WriteLine("Prikaz artikala i kolicine:");
            foreach (var item in query)
            {
                Console.WriteLine(item);
            }

            #endregion


            #region Zadatak Koncert

            Pevac pevac = new Pevac();
            List<Pevac> listaPevaca = pevac.VratiPevace();

            Koncert koncert = new Koncert();
            List<Koncert> listaKoncerata = koncert.VratiKoncerte();

            var queryKoncert = from pev in listaPevaca
                        join kon in listaKoncerata 
                        on pev.PevacId equals kon.PevacId
                        select new
                        {
                            pev.PevacId,
                            pev.Ime,
                            pev.Prezime,
                            kon.BrojKoncerata,
                            kon.Godina
                        };

            Console.WriteLine("----------------");

            Console.WriteLine("Pevaci i koncerti:");

            foreach (var item in queryKoncert)
            {
                Console.WriteLine(item);
            }

            #endregion


            #region Zadatak Kupovina Upgrade

            Proizvodjac proizvodjac = new Proizvodjac();
            List<Proizvodjac> listaProizvodjaca = proizvodjac.VratiProizvodjace();

            var queryUpgrade = from nam in listaNamirnica
                               join k in listaKupovine
                               on nam.NamirnicaId equals k.NamirnicaId
                               join pro in listaProizvodjaca
                               on nam.ProizvodjacId equals pro.ProizvodjacId
                               orderby nam.Artikal
                               select new
                               {
                                   nam.Artikal,
                                   k.Kolicina,
                                   pro.Naziv
                               };

            Console.WriteLine("Sve namirnice i proizvodjaci");

            foreach (var item in queryUpgrade)
            {
                Console.WriteLine(item);
            }

            #endregion


            #region Zadatak Proizvod

            Proizvod p = new Proizvod();
            List<Proizvod> listaProizvoda = p.VratiProizvode();

            Console.WriteLine("Unesite slovo: ");
            string slovo = Console.ReadLine();

            var query6 = from x in listaProizvoda
                         where x.Naziv.ToLower().StartsWith(slovo.ToLower())
                         select x;

            Console.WriteLine("query6");

            foreach (var item in query6)
            {
                Console.WriteLine(item);
            }

            var query7 = (from pp in listaProizvoda
                          select pp.Cena).Sum();

            Console.WriteLine("query7");

            Console.WriteLine(query7);
            

            #endregion

            Console.ReadLine();

        }
    }
}
