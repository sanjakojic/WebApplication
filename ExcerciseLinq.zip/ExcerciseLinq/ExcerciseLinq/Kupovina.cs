﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcerciseLinq
{
    public class Kupovina
    {
        private int id;
        private int namirnicaId;
        private int kolicina;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public int NamirnicaId
        {
            get { return namirnicaId; }
            set { namirnicaId = value; }
        }

        public int Kolicina
        {
            get { return kolicina; }
            set { kolicina = value; }
        }


        public List<Kupovina> VratiSveKupovine()
        {
            List<Kupovina> listaKupovine = new List<Kupovina>();

            listaKupovine.Add(new Kupovina()
            {
                Id = 101,
                NamirnicaId = 1,
                Kolicina = 25
            });

            listaKupovine.Add(new Kupovina()
            {
                Id = 102,
                NamirnicaId = 2,
                Kolicina = 100
            });

            listaKupovine.Add(new Kupovina()
            {
                Id = 103,
                NamirnicaId = 3,
                Kolicina = 45
            });

            listaKupovine.Add(new Kupovina()
            {
                Id = 104,
                NamirnicaId = 4,
                Kolicina = 112
            });

            listaKupovine.Add(new Kupovina()
            {
                Id = 105,
                NamirnicaId = 5,
                Kolicina = 500
            });


            return listaKupovine;
        }

    }
}
