﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractConsoleApp.TestGrupa1
{
    public class Motocikl
    {
        private string Marka;
        private string Model;
        private int Kubikaza;

        public string GetMarka()
        {
            return Marka;
        }

        public void SetMarka(string Marka)
        {
            this.Marka = Marka;
        }

        public string GetModel()
        {
            return Model;
        }

        public void SetModel(string Model)
        {
            this.Model = Model;
        }

        public int GetKubikaza()
        {
            return Kubikaza;
        }

        public void SetKubikaza(int Kubikaza)
        {
            this.Kubikaza = Kubikaza;
        }

        public override string ToString()
        {
            return "Marka: " + Marka + ", Model: " + Model + ",Kubikaza: " + Kubikaza;
        }

        
    }
}
