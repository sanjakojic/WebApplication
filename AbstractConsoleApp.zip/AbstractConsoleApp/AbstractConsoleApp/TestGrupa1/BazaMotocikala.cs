﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractConsoleApp.TestGrupa1
{
    public class BazaMotocikala
    {
        private List<Motocikl> Motocikli;

        public BazaMotocikala()
        {
            Motocikli = new List<Motocikl>();
        }

        public bool DaLiJeUBazi(Motocikl motocikl)
        {
            if (Motocikli.Contains(motocikl))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void UnesiUBazu(Motocikl motocikl)
        {
            if (motocikl != null && !Motocikli.Contains(motocikl))
            {
                Motocikli.Add(motocikl);
            }
            else
            {
                Console.WriteLine("Greska, motocikl je null ili se nalazi u listi.");
            }
        }

        public void IzbaciIzBaze(Motocikl motocikl)
        {
            bool result = DaLiJeUBazi(motocikl);
            if (result)
            {
                Motocikli.Remove(motocikl);
            }
            else
            {
                Console.WriteLine("Greska, nema motocikla u bazi.");
            }
        }


        public void Ispisi()
        {
            foreach (var item in Motocikli)
            {
                Console.WriteLine(item);
            }
        }

    }
}
