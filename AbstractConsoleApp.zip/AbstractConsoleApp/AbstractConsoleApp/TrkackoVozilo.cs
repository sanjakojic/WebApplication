﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractConsoleApp
{
    public class TrkackoVozilo : Vozilo
    {
        private double MaksimalnaBrzina = 0.0;

        public void PostaviMaksimalnuBrzinu(double MaksimalnaBrzina)
        {
            this.MaksimalnaBrzina = MaksimalnaBrzina;
        }

        public override void Ispisi()
        {
            base.Ispisi();
            Console.WriteLine("Maksimalna brzina je: " + MaksimalnaBrzina);
        }
    }
}
