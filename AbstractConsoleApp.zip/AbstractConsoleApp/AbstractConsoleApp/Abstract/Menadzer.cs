﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractConsoleApp.Abstract
{
    public class Menadzer : Zaposleni
    {
        public override void IzracunajPlatu(int brojSati)
        {
            Plata = 1000 * brojSati;
        }
    }
}
