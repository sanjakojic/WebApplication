﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractConsoleApp
{
    public abstract class Zaposleni
    {
        protected double Plata;

        public double GetPlata()
        {
            return Plata;
        }

        public abstract void IzracunajPlatu(int brojSati);
    }
}
