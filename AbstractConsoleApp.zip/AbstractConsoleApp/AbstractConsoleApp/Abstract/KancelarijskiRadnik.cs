﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractConsoleApp.Abstract
{
    public class KancelarijskiRadnik : Zaposleni
    {
        public override void IzracunajPlatu(int brojSati)
        {
            Plata = 100 * brojSati;
        }
    }
}
