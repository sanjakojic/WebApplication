﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AbstractConsoleApp.Abstract;
using AbstractConsoleApp.GeometrijskoTelo;
using AbstractConsoleApp.TestGrupa1;

namespace AbstractConsoleApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Vozilo vozilo = new TrkackoVozilo();
            //vozilo.PostaviNaziv("Audi S8 GT");

            //vozilo.Ispisi();

            //TrkackoVozilo trkackoVozilo = (TrkackoVozilo) vozilo;
            //trkackoVozilo.PostaviMaksimalnuBrzinu(350.0);

            //trkackoVozilo.Ispisi();

            //KancelarijskiRadnik radnik = new KancelarijskiRadnik();
            //radnik.IzracunajPlatu(200);

            //double plataRadnika = radnik.GetPlata();
            //Console.WriteLine("Plata radnika: " + plataRadnika);

            //Menadzer menadzer = new Menadzer();
            //menadzer.IzracunajPlatu(150);

            //double plataMenadzera = menadzer.GetPlata();
            //Console.WriteLine("Plata menadzera: " + plataMenadzera);

            //Kocka kocka = new Kocka();
            //Kvadar kvadar = new Kvadar();

            //kocka.SetDuzinaStranice(25.5);

            //kvadar.SetDuzina(20);
            //kvadar.SetSirina(10);
            //kvadar.SetVisina(30);

            //Console.WriteLine("Povrsina kocke: " + kocka.GetPovrsina());
            //Console.WriteLine("Zapremina kocke: " + kocka.GetZapremina());

            //Console.WriteLine("Povrsina kvadra: " + kvadar.GetPovrsina());
            //Console.WriteLine("Zapremina kvadra: " + kvadar.GetZapremina());

            BazaMotocikala baza = new BazaMotocikala();

            Motocikl m1 = new Motocikl();
            Motocikl m2 = new Motocikl();
            Motocikl m3 = new Motocikl();

            m1.SetMarka("Honda");
            m1.SetModel("CB 750 F");
            m1.SetKubikaza(748);

            m2.SetMarka("Kawasaki");
            m2.SetModel("ER 5");
            m2.SetKubikaza(498);

            m3.SetMarka("Honda");
            m3.SetModel("CB750F");
            m3.SetKubikaza(748);

            baza.UnesiUBazu(m1);
            baza.UnesiUBazu(m2);

            baza.Ispisi();

            bool result = baza.DaLiJeUBazi(m3);
            Console.WriteLine("Da li se nalazi u bazi: " + result);

            if (result)
            {
                baza.IzbaciIzBaze(m3);
            }
            
            baza.Ispisi();

            Console.ReadLine();
        }
    }
}
