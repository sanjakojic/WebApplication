﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractConsoleApp
{
    public class Vozilo
    {
        private string Naziv = "N";

        public void PostaviNaziv(string Naziv)
        {
            this.Naziv = Naziv;
        }

        public virtual void Ispisi()
        {
            Console.WriteLine("Naziv vozila: " + Naziv);
        }
    }
}
