﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractConsoleApp.GeometrijskoTelo
{
    public class Kocka : GeometrijskoTelo
    {
        private double DuzinaStranice;

        public override void IzracunajPovrsinu()
        {
            Povrsina = DuzinaStranice * DuzinaStranice * 6;
        }

        public override void IzracunajZapreminu()
        {
            Zapremina = DuzinaStranice * DuzinaStranice * DuzinaStranice;
        }

        public double GetDuzinaStranice()
        {
            return DuzinaStranice;
        }

        public void SetDuzinaStranice(double duzinaStranice)
        {
            if (duzinaStranice <= 0)
            {
                Console.WriteLine("Greska, duzina ne sme biti manja ili jednaka nuli.");
            }
            else
            {
                DuzinaStranice = duzinaStranice;
            }
        }
    }
}
