﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractConsoleApp.GeometrijskoTelo
{
    public class Kvadar : GeometrijskoTelo
    {
        private double Duzina;
        private double Sirina;
        private double Visina;

        public void SetDuzina(double duzina)
        {
            if (duzina <= 0)
            {
                Console.WriteLine("Greska, duzina ne sme biti manja ili jednaka nuli.");
            }
            else
            {
                Duzina = duzina;
            }
        }

        public double GetDuzina()
        {
            return Duzina;
        }

        public void SetSirina(double sirina)
        {
            if (sirina <= 0)
            {
                Console.WriteLine("Greska, sirina ne sme biti manja ili jednaka nuli.");
            }
            else
            {
                Sirina = sirina;
            }
        }

        public double GetSirina()
        {
            return Sirina;
        }

        public void SetVisina(double visina)
        {
            if (visina <= 0)
            {
                Console.WriteLine("Greska, visina ne sme biti manja ili jednaka nuli.");
            }
            else
            {
                Visina = visina;
            }
        }

        public double GetVisina()
        {
            return Visina;
        }


        public override void IzracunajPovrsinu()
        {
            Povrsina = 2 * (Duzina * Visina) + 2 * (Sirina * Visina) + 2 * (Duzina * Sirina);
        }

        public override void IzracunajZapreminu()
        {
            Zapremina = Duzina * Sirina * Visina;
        }
    }
}
