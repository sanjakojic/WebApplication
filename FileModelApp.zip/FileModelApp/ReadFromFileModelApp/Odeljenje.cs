﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadFromFileModelApp
{
    public class Odeljenje
    {
        List<Djak> djaci = new List<Djak>();


        public void UcitajIzFajla()
        {
            string path = @"C:\Users\Student\Desktop\Djaci.txt";

            using (StreamReader sr = File.OpenText(path))
            {
                string linija = string.Empty;
                while ((linija = sr.ReadLine()) != null )
                {
                    string[] nizReci = linija.Split(' ');
                    Djak djak = new Djak();
                    djak.Ime = nizReci[0];
                    djak.Prezime = nizReci[1];
                    djak.Ocena = int.Parse(nizReci[2]);

                    if (!djaci.Contains(djak))
                    {
                        djaci.Add(djak);
                    }
                    else
                    {
                        throw new Exception($"Ucenik {djak.Ime} {djak.Prezime} vec je unet.");
                    }
                }
                
            }
        }

        public void UpisiOdlicne()
        {
            string path = @"C:\Users\Student\Desktop\odlicni_ucenici.txt";

            using (StreamWriter sr = File.AppendText(path))
            {
                foreach (var item in djaci)
                {
                    if(item.Ocena == 5)
                    {
                        sr.WriteLine(item.ToString());
                    }
                }
                sr.Close();
            }
        }

    }
}
