﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadFromFileModelApp
{
    public class Djak
    {
        private string ime;
        private string prezime;
        private int ocena;


        public string Ime
        {
            get { return ime; }
            set
            {
                if (value != null)
                {
                    ime = value;
                }
                else
                {
                    throw new Exception("Ime ne sme biti null.");
                }
            }
        }


        public string Prezime
        {
            get { return prezime; }
            set
            {
                if (value != null)
                {
                    prezime = value;
                }
                else
                {
                    throw new Exception("Prezime ne sme biti null.");
                }
            }
        }


        public int Ocena
        {
            get { return ocena; }
            set
            {
                if(value >=1 && value <= 5)
                {
                    ocena = value;
                }
                else
                {
                    throw new Exception("Ocena mora biti u rasponu od 1 do 5.");
                }
            }
        }

        public override string ToString()
        {
            return ime + " " + prezime + " " + ocena;
        }


    }
}
